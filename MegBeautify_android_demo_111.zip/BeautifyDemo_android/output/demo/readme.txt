1、创建目录/sdcard/megvii_batch_proc，将所有图片放置在此文件夹中；
2、拷贝BeautifyParams.xml文件至1的文件夹中,此文件用于参数设置0.0-5.0;
3、运行app首页的批量处理按钮；
4、等所有的图片处理完，结果保存在/sdcard/DCIM/Camera/megBeautify中。