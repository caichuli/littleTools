package com.megvii.beautify.cameragl;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.ImageFormat;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.graphics.YuvImage;
import android.hardware.Camera;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.megvii.beautify.R;
import com.megvii.beautify.app.MainApp;
import com.megvii.beautify.camera.CameraWrapper;
import com.megvii.beautify.component.SensorEventUtil;
import com.megvii.beautify.jni.BeaurifyJniSdk;
import com.megvii.beautify.main.MainActivity;
import com.megvii.beautify.util.CaptureUtil;
import com.megvii.beautify.util.ConUtil;
import com.megvii.beautify.util.ImageUtils;
import com.megvii.beautify.util.LandMarkMatrix;
import com.megvii.beautify.util.MLog;
import com.megvii.beautify.util.NV21Matrix;
import com.megvii.beautify.util.NoDoubleClickUtil;
import com.megvii.beautify.util.Util;
import com.megvii.beautify.video.TextureMovieEncoder;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import static android.opengl.GLES30.*;

/**
 * Created by liyanshun on 2017/7/3.
 */

public class CameraRender implements GLSurfaceView.Renderer, SurfaceTexture.OnFrameAvailableListener, CameraWrapper.ICameraCallback {
    private static final  String TAG = "CameraRender";

    private static boolean USE_OES_TEXTURE = true;
    private Context mContext;
    private int mWidth, mHeight;
    private SurfaceTexture mSurfaceTexture;
    private CameraManager mCameraManager;
    private ICameraMatrix mCameraMatrix;
    private ImageMatrix mImageMatrix;
    private final FloatBuffer mVertexBuffer;
    private final FloatBuffer mTextureBuffer;
    private int current_out_tex_idx = 0;
    //the pay load of min face, modify this parameter to larger values will cause the
    //detect face faster.
    private final static int FACE_DETECT_BALANCE_PARAM = 8;
    public int mRenderW = 960;
    public int mRenderH = 540;

    public boolean mCameraChange = false;

    private ByteBuffer mOutData;

    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM-dd-HH_mm_ss");

    /**
     * OpenGL params
     */
//    private ByteBuffer mFullQuadVertices;
    private CameraSurfaceView.RequestRenderListener requestRenderListener;
    private boolean drawCamera = false;
    private int[] mOutTextureId;
    private int mFrontTexture;
    private int mOES_Texture;
    float[] textureCords;
    private ICameraOESMatrix mCameraOESMatrix;
    private LandMarkMatrix mLandMarkMatrix = new LandMarkMatrix();

    public static boolean mDebugConcurrent=false;
    private Bitmap decodeBitmap;
    public  static  boolean mockCapture=true;


    private volatile RenderMessageBean messageBean = RenderMessageBean.getInstance();

    /**
     * 解决红米米黑屏的问题  update完了之后直接切换到available 变量就重置不成功了
     * 后期尝试去掉变量
     * update已经去掉变量
     */
    private NV21Matrix nv21Matrix = new NV21Matrix();

    //texture转为buffer
    private TexureToBufferHelper mBufferhelper;
    private SensorEventUtil sensorUtil;
    private CaptureUtil mCaptureUtil;
    public TextureMovieEncoder movieEncoder;

    // for capture postprogress
    private HandlerThread mCaptureHandlerThread;
    private Handler mCaptureHandler;
    private boolean mIsInPostprogress = false;
    private static final int MSG_INIT_HANDLE = 0;

    private boolean mIsSdkInited = false;
    private boolean mNeedInitFlag = true;

    public CameraRender(Context context, CameraManager cameraManager, SensorEventUtil sensorUtil) {
        mContext = context;
        mCameraManager = cameraManager;
        mCameraMatrix = new ICameraMatrix(context);
        mImageMatrix = new ImageMatrix(context);
        mCameraOESMatrix = new ICameraOESMatrix(context);

        this.sensorUtil = sensorUtil;
        mCaptureUtil = new CaptureUtil(context, new CaptureUtil.GLExecutor() {
            @Override
            public void runOnRenderThread(Runnable runnable) {
                if (requestRenderListener != null) {
                    requestRenderListener.runOnRenderThread(runnable);
                }
            }
        });
        mVertexBuffer = ByteBuffer.allocateDirect(OpenglUtil.CUBE.length * 4).order(ByteOrder.nativeOrder())
                .asFloatBuffer();
        System.out.println("native order is " + ByteOrder.nativeOrder());

        mVertexBuffer.put(OpenglUtil.CUBE).position(0);

        mTextureBuffer = ByteBuffer.allocateDirect(OpenglUtil.TEXTURE_NO_ROTATION.length * 4)
                .order(ByteOrder.nativeOrder()).asFloatBuffer();
        mTextureBuffer.put(OpenglUtil.TEXTURE_NO_ROTATION).position(0);

        mBufferhelper = new TexureToBufferHelper();

        mCaptureHandlerThread = new HandlerThread("CaptureThread");

        mCaptureHandlerThread.start();

        mCaptureHandler = new Handler(mCaptureHandlerThread.getLooper()) {
            @Override
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case MSG_INIT_HANDLE:
                        if (mNeedInitFlag) {
                            initImageHandle();
                            mNeedInitFlag = false;
                        }
                        break;
                    default:
                        break;
                }
            }
        };
    }


    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        MLog.e("surface create ");

        //加载美瞳模板资源
        //Util.initTemplates(mContext);

    }

    private boolean isOESMode(){
        boolean oesMode =  USE_OES_TEXTURE && !Util.isTestHAL;
        //Log.e(TAG, "isOESMode " + oesMode);
        return oesMode;
    }


    private void swapIndex(){
        if (current_out_tex_idx == 0){
            current_out_tex_idx = 1;
        } else {
            current_out_tex_idx = 0;
        }
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        if (mCameraManager.mCameraWrapper == null) {
            MLog.e("camera open fail");
            return;
        }
        if (NoDoubleClickUtil.isDoubleChanged()) {
            //防止异常
            MLog.e("surface changed twice");
            return;
        }
        MLog.e("surface changed width:" + width + " height:" + height);

        if(mOutTextureId != null) {
            if(mWidth == width && mHeight == height && !mCameraChange){
                return;
            }
            else {
                //onDestroy();
                if(mCameraChange){
                    mCameraChange = false;
                }
            }
        }

        mRenderW = mCameraManager.cameraWidth;
        mRenderH = mCameraManager.cameraHeight;
        mWidth = width;
        mHeight = height;
        messageBean.width = mCameraManager.cameraWidth;
        messageBean.height = mCameraManager.cameraHeight;

        GLES20.glClearColor(0, 0, 0, 1.0f);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);

        if (mCameraManager.isFrontCam()) {
            textureCords = OpenglUtil.TEXTURE_ROTATED_FRONT;
        } else {
            textureCords = OpenglUtil.TEXTURE_ROTATED_BACK;
        }

        mTextureBuffer.clear();
        mTextureBuffer.put(textureCords).position(0);

        //set up surfacetexture------------------

        if (isOESMode()){
            if (mOES_Texture > 0) {
                int[] oesTexture = new int[1];
                oesTexture[0] = mOES_Texture;
                GLES20.glDeleteTextures(1, oesTexture, 0);
            }
            mOES_Texture = mCameraMatrix.getOESTexture();
            //mCameraManager.setViewPort(width, height);
            if (mSurfaceTexture != null) {
                mSurfaceTexture.release();
            }
            mSurfaceTexture = new SurfaceTexture(mOES_Texture);
        }else {
            if (mFrontTexture > 0) {
                int[] frontTexture = new int[1];
                frontTexture[0] = mFrontTexture;
                GLES20.glDeleteTextures(1, frontTexture, 0);
            }
            mFrontTexture = mCameraMatrix.get2DTextureID();
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, mFrontTexture);
            glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA,
                    mRenderW, mRenderH, 0,
                    GLES20.GL_RGBA,
                    GLES20.GL_UNSIGNED_BYTE, null);
            //mCameraManager.setViewPort(width, height);
            if (mSurfaceTexture != null) {
                mSurfaceTexture.release();
            }
            mSurfaceTexture = new SurfaceTexture(10);
        }

        // Set the default size of the image buffers.
        mSurfaceTexture.setDefaultBufferSize(mRenderW, mRenderH);

        mCameraManager.actionDetect(this);
        mCameraManager.startPreview(mSurfaceTexture);
        Matrix.setIdentityM(mtx, 0);
        if (isOESMode()) {
            mSurfaceTexture.updateTexImage();
            mCameraOESMatrix.init(mCameraManager.isFrontCam());
            mCameraOESMatrix.initCameraFrameBuffer(mRenderW, mRenderH);
            mCameraOESMatrix.onOutputSizeChanged(mRenderW, mRenderH);
            mCameraOESMatrix.setTextureTransformMatrix(mtx);
        }else {
            //双缓冲
            mCameraMatrix.init(mCameraManager.isFrontCam());
            mCameraMatrix.initCameraFrameBuffer(mRenderW, mRenderH);
            mCameraMatrix.onOutputSizeChanged(mRenderW, mRenderH);
            mCameraMatrix.setTextureTransformMatrix(mtx);
        }

        mImageMatrix.init();
        if (mOutTextureId != null) {
            GLES20.glDeleteTextures(mOutTextureId.length, mOutTextureId, 0);
        }
        mOutTextureId = OpenglUtil.initTextureID(mRenderW, mRenderH);
        MLog.e("onSurfaceChanged: " + Thread.currentThread().getId() + "angle" + mCameraManager.Angle);

        // 初始化美颜
        GLES20.glViewport(0, 0, width, height);

        // changeImageDisplaySize(width, height);
        sceenAutoFit(mWidth, mHeight, mCameraManager.cameraWidth, mCameraManager.cameraHeight, mCameraManager.Angle);

        MLog.e("onSurfaceChanged: " + Thread.currentThread().getId() + ",sw=" + width + ",sh=" + height + ",cw=" + mCameraManager.cameraWidth + ",ch=" + mCameraManager.cameraHeight + ",angle=" + mCameraManager.Angle);

        mBufferhelper.onOutputSizeChanged(mRenderW, mRenderH);

        mIsSdkInited = true;
        Log.i(TAG, "nativeCreateBeautyHandle----start");
        BeaurifyJniSdk.preViewInstance().nativeReleaseResources();
        BeaurifyJniSdk.preViewInstance().nativeSetLogLevel(BeaurifyJniSdk.MG_LOG_LEVEL_DEBUG);
        BeaurifyJniSdk.preViewInstance().nativeCreateBeautyHandle(mContext,
                mRenderW,
                mRenderH,
                mCameraManager.Angle
                , Util.MG_FPP_DENSEDETECTIONMODE_PREVIEW,
                ConUtil.getFileContent(mContext, R.raw.mgbeautify_1_2_4_model),
                ConUtil.getFileContent(mContext, R.raw.detect_model),
                null
        );

        BeaurifyJniSdk.preViewInstance().nativeUseFastFilter(false);
        initBeautyParam(PREVIEW_INSTANCE);
        Log.i(TAG, "nativeCreateBeautyHandle----end");
        initBeautyParam(PREVIEW_INSTANCE);
        mCaptureHandler.sendEmptyMessage(MSG_INIT_HANDLE);
    }

    float[] mtx = new float[16];
    @Override
    public void onDrawFrame(GL10 gl) {

        if(mImageMatrix == null)
            return;
        if(Util.isDebuging){
            messageBean.traceFps("onDrawFrame");
            messageBean.traceStart("onDrawFrame_All");
        }
        if (Util.isTestHAL){
            drawTestHALFrame(gl);
        }else {
            drawNormalFrame(gl);
        }
        if(Util.isDebuging){
            messageBean.traceEnd("onDrawFrame_All");
        }

    }
    public void drawNormalFrame(GL10 gl) {
        //messageBean.traceStart("drawNormalFrame_All");
        //messageBean.traceStart("drawNormalFrame1");

        if (Util.isFilterChanged || !Util.isFilterParamInited) {   //滤镜有变更或者未初始化
            if (TextUtils.isEmpty(Util.filterPath)) {
                BeaurifyJniSdk.preViewInstance().nativeRemoveFilter();
            } else {
                BeaurifyJniSdk.preViewInstance().nativeSetFilter(Util.filterPath);
            }
            Util.isFilterParamInited = true;
            Util.isFilterChanged = false;

        }

        if (Util.isStickerChanged || !Util.isStickerParamInited) {   //sticker有变更或者未初始化
            if (TextUtils.isEmpty(Util.sCurrentStickerPath)) {
                BeaurifyJniSdk.preViewInstance().nativeDisablePackage();
            } else {
                BeaurifyJniSdk.preViewInstance().nativeChangePackage(Util.sCurrentStickerPath);
            }
            Util.isStickerParamInited = true;
            Util.isStickerChanged = false;
        }

        GLES20.glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);

        int textureID;
        if(isOESMode()) {
            textureID = mCameraOESMatrix.onDrawToTexture(mOES_Texture);
        }else {
            textureID = mCameraMatrix.onDrawToTexture(mFrontTexture);
        }

        int frameTexture = 0;
        if(!Util.isShowOriPic && mIsSdkInited){
            mCameraManager.lock.lock();
            BeaurifyJniSdk.preViewInstance().nativeProcessTexture(textureID, mOutTextureId[current_out_tex_idx]);
           // BeaurifyJniSdk.preViewInstance().nativeProcessImageInTextureOut(mCameraManager.mDataCache,mCameraManager.cameraWidth,mCameraManager.cameraHeight,mOutTextureId[current_out_tex_idx]);
//            byte[] outImage = new byte[mCameraManager.cameraWidth*mCameraManager.cameraHeight*3/2];
//            BeaurifyJniSdk.preViewInstance().nativeProcessImageInImageOutNV21(mCameraManager.mDataCache,outImage,mCameraManager.cameraWidth,mCameraManager.cameraHeight);
            mCameraManager.lock.unlock();
            swapIndex();

            frameTexture = mOutTextureId[current_out_tex_idx];
        }else{
            frameTexture = textureID;
        }

        if (Util.isDebugingLandMark) {
            mLandMarkMatrix.drawLandMark(frameTexture
                    , mRenderW
                    , mRenderH);
        }

        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);
        GLES20.glViewport(0, 0, mWidth, mHeight);

        mImageMatrix.onDrawFrame(frameTexture, mVertexBuffer, mTextureBuffer);

        movieEncoder.setTextureId(frameTexture);

        movieEncoder.frameAvailable(mSurfaceTexture);

        if(isOESMode()){
            mSurfaceTexture.updateTexImage();
        }

        if (mDebugConcurrent&&mockCapture){

            MainApp.getBackgroundHandler().post(new Runnable() {
                @Override
                public void run() {
                    Bitmap mOutBmp=null;
                    if(mOutBmp == null){
                        mOutBmp = decodeBitmap.copy(decodeBitmap.getConfig(), decodeBitmap.isMutable());
                    }
                    BeaurifyJniSdk.imageInstance().nativeShareGLContext();
                    BeaurifyJniSdk.imageInstance().nativeReset(decodeBitmap.getWidth(),decodeBitmap.getHeight(),0);
//                    BeaurifyJniSdk.imageInstance().nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_DENOISE, Util.CURRENT_MG_BEAUTIFY_DENOISE);
//                    BeaurifyJniSdk.imageInstance().nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_BRIGHTNESS, Util.CURRENT_MG_BEAUTIFY_BRIGHTNESS);
//                    BeaurifyJniSdk.imageInstance().nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_SHRINK_FACE, Util.CURRENT_MG_BEAUTIFY_SHRINK_FACE);
//                    BeaurifyJniSdk.imageInstance().nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_ENLARGE_EYE, Util.CURRENT_MG_BEAUTIFY_ENLARGE_EYE);
                    BeaurifyJniSdk.imageInstance().nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_DENOISE, 5.0f);
                    BeaurifyJniSdk.imageInstance().nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_BRIGHTNESS, 5.0f);
                    BeaurifyJniSdk.imageInstance().nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_SHRINK_FACE, 5.0f);
                    BeaurifyJniSdk.imageInstance().nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_ENLARGE_EYE, 5.0f);
                    BeaurifyJniSdk.imageInstance().nativeProcessImage(decodeBitmap, mOutBmp);
                    BeaurifyJniSdk.imageInstance().nativeDoneGLContext();
                    ((MainActivity)mContext).showDebugImg(mOutBmp);
                    mockCapture=false;
                }
            });
        }



        //messageBean.traceEnd("drawNormalFrame2");
       // messageBean.traceEnd("drawNormalFrame_All");
    }

    public void drawTestHALFrame(GL10 gl) {
        GLES20.glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
        Matrix.setIdentityM(mtx, 0);
        //mSurfaceTexture.getTransformMatrix(mtx);
        mCameraMatrix.setTextureTransformMatrix(mtx);

        int textureID = mCameraMatrix.onDrawToTexture(mFrontTexture);
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);
        GLES20.glViewport(0, 0, mWidth, mHeight);

        mImageMatrix.onDrawFrame(textureID, mVertexBuffer, mTextureBuffer);

    }
    private void updateTexture(final byte[] data) {
        if(isOESMode()){
            //do nothing
            //mSurfaceTexture.updateTexImage();
        } else {
            long start = System.currentTimeMillis();
            nv21Matrix.setOutputSize(mRenderW, mRenderH);
            nv21Matrix.renderNv21(data
                    , mFrontTexture
                    , mCameraManager.cameraWidth
                    , mCameraManager.cameraHeight
                    , mCameraManager.isFrontCam());
            Log.i(TAG, "renderNv21.cost=" + (System.currentTimeMillis() - start));
        }
    }

    /**
     * 主线程
     *
     * @param surfaceTexture
     */
    @Override
    public void onFrameAvailable(SurfaceTexture surfaceTexture) {
        MLog.e(" onFrameAvailable startRequestRender" + Thread.currentThread().getId());
    }


    public void setRequestRenderListener(CameraSurfaceView.RequestRenderListener requestRenderListener) {
        this.requestRenderListener = requestRenderListener;
    }

    private void changeImageDisplaySize(int width, int height) {
        int outputWidth = width;
        int outputHeight = height;
        if (mCameraManager.Angle == 270 || mCameraManager.Angle == 90) {
            outputWidth = height;
            outputHeight = width;
        }
        float ratio1 = (float) outputWidth / mCameraManager.cameraWidth;
        float ratio2 = (float) outputHeight / mCameraManager.cameraHeight;
        float ratioMax = Math.max(ratio1, ratio2);
        int imageWidthNew = Math.round(mCameraManager.cameraWidth * ratioMax);
        int imageHeightNew = Math.round(mCameraManager.cameraHeight * ratioMax);

        float ratioWidth = imageWidthNew / (float) outputWidth;
        float ratioHeight = imageHeightNew / (float) outputHeight;

        if (mCameraManager.Angle == 270 || mCameraManager.Angle == 90) {
            ratioWidth = imageHeightNew / (float) outputHeight;
            ratioHeight = imageWidthNew / (float) outputWidth;
        }

        //从手机顶端开始绘制
        float offset_width = (float) (1.0f - 1.0 / ratioWidth);
        float offset_height = (float) (1.0f - 1.0 / ratioHeight);
        float[] cube = new float[]{
                OpenglUtil.CUBE[0] / ratioHeight + offset_height, OpenglUtil.CUBE[1] / ratioWidth + offset_width,
                OpenglUtil.CUBE[2] / ratioHeight + offset_height, OpenglUtil.CUBE[3] / ratioWidth + offset_width,
                OpenglUtil.CUBE[4] / ratioHeight + offset_height, OpenglUtil.CUBE[5] / ratioWidth + offset_width,
                OpenglUtil.CUBE[6] / ratioHeight + offset_height, OpenglUtil.CUBE[7] / ratioWidth + offset_width};
        mVertexBuffer.clear();
        mVertexBuffer.put(cube).position(0);
    }


    /**
     * 按照centercrop的源码修改，这里viewport相当于已经做过scale了，
     * 所以不需要额外scale，但是dx不需要除以2还不理解，centercrop 是要除的。
     *
     * @param screenW
     * @param screenH
     * @param cameraW
     * @param cameraH
     * @param angle
     */
    public void sceenAutoFit(int screenW, int screenH, int cameraW, int cameraH, int angle) {
        if (angle == 90 || angle == 270) {
            int temp = cameraW;
            cameraW = cameraH;
            cameraH = temp;
        }
        float scale;
        float dx = 0, dy = 0;
        float dxRatio = 0f;
        float dyRatio = 0f;


        if (cameraW * screenH > screenW * cameraH) {
            scale = (float) screenH / (float) cameraH;
            dx = (screenW - cameraW * scale);
            dxRatio = dx / screenW;
        } else {
            scale = (float) screenW / (float) cameraW;
            dy = (screenH - cameraH * scale);
            dyRatio = dy / screenH;
        }
        float[] cube = new float[]{
                OpenglUtil.CUBE[0] + dxRatio, OpenglUtil.CUBE[1] + dyRatio,
                OpenglUtil.CUBE[2] - dxRatio, OpenglUtil.CUBE[3] + dyRatio,
                OpenglUtil.CUBE[4] + dxRatio, OpenglUtil.CUBE[5] - dyRatio,
                OpenglUtil.CUBE[6] - dxRatio, OpenglUtil.CUBE[7] - dyRatio};
        mVertexBuffer.clear();
        mVertexBuffer.put(cube).position(0);
    }

    private byte[] yuv;

    public byte[] scaleUV420(byte[] data, int width, int height, int scale, int[] sz) {
        Log.e(TAG, "data length is " + data.length);
        int w = width / scale;
        int h = height / scale;

        if (w % 2 == 1) {
            w += 1;
        }
        if (h % 2 == 1) {
            h += 1;
        }
        sz[0] = w;
        sz[1] = h;
        if (yuv == null || yuv.length!= w * h + w * h / 2) {
            yuv = new byte[w * h + w * h / 2];
        }
        int i = 0;
        for (int k = 0; k < height; k += scale) {
            for (int m = 0; m < width; m += scale) {
                yuv[i] = data[k * width + m];
                i++;
            }
        }
        int size = width * height;
        i = w * h;
        for (int k = 0; k < height / 2; k += scale) {
            for (int m = 0; m < width; m += (2 * scale)) {
                if (i < yuv.length) {
                    yuv[i] = data[size + (k * width) + m];
                    i++;
                }
                if (i < yuv.length) {
                    yuv[i] = data[size + (k * width) + m + 1];
                    i++;
                }
            }
        }
        assert (i == size + size / 2);
        return yuv;
    }

    private ExecutorService threadPoolExecutor = (ExecutorService) Executors.newSingleThreadExecutor();

    private int[] frontPoints = new int[Util.LandMarkPointSize];

    public static interface TakePictureCallBack{
        void onTakPicture(Buffer byteBuffer);
    }

    public void takePicture(final boolean isFrontCam, final Runnable callback){
        int frameTexture = mOutTextureId[0];
        mCaptureUtil.takePicture(frameTexture
                , mRenderW
                , mRenderH
                , mCameraManager.cameraHeight
                , mCameraManager.cameraWidth
                , isFrontCam
                , callback);
    }

    // 拍照处理
    public void postProcess() {
        mCameraManager.takePicture();
    }

    private void reverseBuf(ByteBuffer buf, int width, int height)
    {
        long ts = System.currentTimeMillis();
        int i = 0;
        byte[] tmp = new byte[width * 4];
        while (i++ < height / 2)
        {
            buf.get(tmp);
            System.arraycopy(buf.array(), buf.limit() - buf.position(), buf.array(), buf.position() - width * 4, width * 4);
            System.arraycopy(tmp, 0, buf.array(), buf.limit() - buf.position(), width * 4);
        }
        buf.rewind();
        Log.d(TAG, "reverseBuf took " + (System.currentTimeMillis() - ts) + "ms");
    }

    public Buffer readToBuffer(){

        ByteBuffer buf = ByteBuffer.allocateDirect(mWidth * mHeight * 4);
        buf.order(ByteOrder.LITTLE_ENDIAN);
        GLES20.glReadPixels(0, 0, mWidth, mHeight, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf);
        reverseBuf(buf, mWidth, mHeight);
        return buf;
    }

    public Bitmap getBitmap(Buffer buf) {
        Bitmap bmp = Bitmap.createBitmap(mWidth, mHeight, Bitmap.Config.ARGB_8888);
        bmp.copyPixelsFromBuffer(buf);
        return bmp;
    }

    public void save(Bitmap bmp, String filename){
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(filename);
            bmp.compress(Bitmap.CompressFormat.PNG, 100, out); // bmp is your Bitmap instance
            // PNG is a lossless format, the compression factor (100) is ignored
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    byte[] halTestData;
    private boolean isProcessing;
    private  void dealwithFrameTestHAL(final byte[] data, final Camera camera) {
        if(halTestData == null || halTestData.length!= data.length){
            halTestData = new byte[data.length];
        }
        if(isProcessing){
            return;
        }
        isProcessing = true;
        Future<Integer> future =   threadPoolExecutor.submit(new Callable<Integer>() {
            @Override
            public Integer call() throws Exception {
                if(isReleased){
                    return 0;
                }
                Util.testHALProcessNV21Video(mContext, data, halTestData, mCameraManager.cameraWidth, mCameraManager.cameraHeight);

                if (requestRenderListener != null) {
                    requestRenderListener.runOnRenderThread(new Runnable() {
                        @Override
                        public void run() {
                            updateTexture(halTestData);
                        }
                    });
                }
                requestRenderListener.startRequestRender();
                isProcessing = false;
                return 0;
            }
        });

    }


    private  void dealwithFrame(final byte[] data, final Camera camera) {
        if (requestRenderListener != null) {
            requestRenderListener.runOnRenderThread(new Runnable() {
                @Override
                public void run() {
                    updateTexture(data);
                }
            });
        }
        double xScale = mRenderW/(double)mCameraManager.cameraWidth;
        double yScale = mRenderH/(double)mCameraManager.cameraHeight;

        // 美颜
        if (mIsSdkInited) {
            onDectBeauty(data, xScale, yScale, mCameraManager.cameraWidth
                    , mCameraManager.cameraHeight);
        }
        if (Util.isDebugingLandMark) {
            //BeaurifyJniSdk.preViewInstance().nativeGetDenseLMPoints(frontPoints);
            BeaurifyJniSdk.preViewInstance().nativeGetPoints(frontPoints);
            mLandMarkMatrix.setPoints(frontPoints);
        }

    }

    //byte[] dataCache;
    @Override
    public void onPreviewFrame(byte[] data, Camera camera) {
        if(Util.isDebuging){
            messageBean.traceFps("onPreviewFrame");
            messageBean.traceStart("onPreviewFrame");
        }

        if (Util.isTestHAL){
            dealwithFrameTestHAL(data, camera);
        }else {
            dealwithFrame(data, camera);
        }
        requestRenderListener.startRequestRender();
        if(Util.isDebuging){
            messageBean.traceEnd("onPreviewFrame");
        }

    }

    @Override
    public void onCapturePicture(final byte[] bytes) {
        if (mIsInPostprogress) {
            return;
        } else {
            mIsInPostprogress = true;
        }

        mCaptureHandler.post(new Runnable() {
            @Override
            public void run() {
                postProcessHandle(bytes);
            }
        });

        Toast.makeText(mContext, "Save picture success.", Toast.LENGTH_SHORT).show();
    }

    private void saveToBitmap(String filePath, byte[] data, int format, int width, int height, int[] strides) {
        File f = new File(filePath);
        try {
            f.createNewFile();
        } catch (IOException e) {
        }
        FileOutputStream fOut = null;
        try {
            fOut = new FileOutputStream(f);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        YuvImage image = new YuvImage(data, format, width, height, strides);

        image.compressToJpeg(new Rect(0, 0, width, height), 100, fOut);

        try {
            fOut.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    // 拍照后处理
    private void postProcessHandle(byte[] inNV21) {

//        byte[] bokehNV21 = new byte[inNV21.length];
        byte[] outNV21 = new byte[inNV21.length];

        int width = mCameraManager.getPictureWidth();
        int height = mCameraManager.getPictureHeight();

//        System.arraycopy(inNV21, 0, bokehNV21, 0, inNV21.length);

        Log.i(TAG, "postProcessHandle start, width=" + width + ", height=" + height);

        BeaurifyJniSdk.imageInstance().nativeShareGLContext();

        Thread.currentThread().setPriority(Thread.MAX_PRIORITY);

        BeaurifyJniSdk.imageInstance().nativeReset(width, height, mCameraManager.Angle);

        if (Util.isPostFilterChanged || !Util.isPostFilterParamInited) {   //滤镜有变更或者未初始化
            if (TextUtils.isEmpty(Util.filterPath)) {
                BeaurifyJniSdk.imageInstance().nativeRemoveFilter();
                Log.i(TAG, "postProcessHandle nativeRemoveFilter: " + Util.filterPath);
            } else {
                BeaurifyJniSdk.imageInstance().nativeSetFilter(Util.filterPath);
                Log.i(TAG, "postProcessHandle nativeSetFilter: " + Util.filterPath);
            }
            Util.isPostFilterParamInited = true;
            Util.isPostFilterChanged = false;
        }

        BeaurifyJniSdk.imageInstance().nativeProcessImageNV21(inNV21, outNV21, width, height);
        Log.i(TAG, "postProcessHandle nativeDoneGLContext start");
        BeaurifyJniSdk.imageInstance().nativeDoneGLContext();
        Log.i(TAG, "postProcessHandle nativeDoneGLContext end");

        String dirPath = "/sdcard/megvii_picture/post/";

        File dir = new File(dirPath);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        String outJpgFileName = "out" + "." + simpleDateFormat.format(new Date()) + "." + (System
                .currentTimeMillis() % 1000) + "_" + width + "x" + height + ".jpg";
        Log.i(TAG, "posT saveToBitmap -- start--");

        saveToBitmap(dirPath + outJpgFileName, outNV21, ImageFormat.NV21, width, height, null);

        Log.i(TAG, "postProcessHandle saveToBitmap -- end --");

        mIsInPostprogress = false;

        Log.i(TAG, "postProcessHandle end....");
    }

    int rotation = 0;
    private void onDectBeauty(final byte[] data, double xScale, double yScale,  final int cameraWidth, final int cameraHeight) {
        //long faceTime = System.currentTimeMillis();
        final int orientation = sensorUtil.orientation;
        if (orientation == 0)
            rotation = mCameraManager.Angle;
        else if (orientation == 1)
            rotation = 0;
        else if (orientation == 2)
            rotation = 180;
        else if (orientation == 3)
            rotation = 360 - mCameraManager.Angle;
        BeaurifyJniSdk.preViewInstance().nativeDetectFaceOrientation(data, xScale, yScale, cameraWidth, cameraHeight
                , Util.MG_IMAGEMODE_GRAY, mCameraManager.Angle);
    }


    public void deleteTextures(GLSurfaceView mGlSurfaceView) {
        mGlSurfaceView.queueEvent(new Runnable() {
            @Override
            public void run() {
                MLog.e("onSurfaceChanged: queueEvent" + Thread.currentThread().getId());
                if(mCameraMatrix != null){
                    mCameraMatrix.destroyFramebuffers();
                    mCameraMatrix.destroy();
                }
                if(mImageMatrix != null){
                   mImageMatrix.destroy();
                }
                if(mBufferhelper != null){
                    mBufferhelper.destroy();
                }
                // GLES20.glDeleteTextures(1, mTextureIds, 0);
                if (mOutTextureId != null) {
                    GLES20.glDeleteTextures(2, mOutTextureId, 0);
                    mOutTextureId = null;
                }
        }
        });
    }

    private boolean isReleased = false;
    public void onDestroy() {
        if(null != mSurfaceTexture)
        {
            mSurfaceTexture.release();
            mSurfaceTexture = null;
        }
        Log.i(TAG, "**********onDestroy**********");
        BeaurifyJniSdk.preViewInstance().nativeReleaseResources();
        BeaurifyJniSdk.imageInstance().nativeReleaseResources();
        mNeedInitFlag = true;

        Util.isFilterParamInited = false;
        Util.isPostFilterParamInited = false;
        Util.isStickerParamInited = false;
        Future<Integer> future =   threadPoolExecutor.submit(new Callable<Integer>() {
            @Override
            public Integer call() throws Exception {
                Util.testHALReleaseNV21Video();
                isReleased = true;
                return 0;
            }
        });
        try {
            future.get();
        }catch (Throwable throwable){

        }

    }

    private final int PREVIEW_INSTANCE = 0;
    private final int IMAGE_INSTANCE = 1;

    private void initBeautyParam(int instanceType) {
        BeaurifyJniSdk jniSdk;
        if (instanceType == PREVIEW_INSTANCE) {
            jniSdk = BeaurifyJniSdk.preViewInstance();
        } else if (instanceType == IMAGE_INSTANCE) {
            jniSdk = BeaurifyJniSdk.imageInstance();
        } else {
            Log.w(TAG, "wrong instance type : " + instanceType);
            return;
        }

        if (mCameraManager.isFrontCam()) {
            jniSdk.nativeSetStickerParam(1.0f);
        } else {
            jniSdk.nativeSetStickerParam(0.0f);
        }

        jniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_DENOISE, Util.CURRENT_MG_BEAUTIFY_DENOISE);
        jniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_BRIGHTNESS, Util.CURRENT_MG_BEAUTIFY_BRIGHTNESS);
        jniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_BRIGHTEN_EYE,Util.CURRENT_MG_BEAUTIFY_BRIGHTEN_EYE);
        jniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_TOOTH,Util.CURRENT_MG_BEAUTIFY_TOOTH);
        jniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_ADD_PINK, Util.CURRENT_MG_BEAUTIFY_ADD_PINK);

        jniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_SHRINK_FACE, Util.CURRENT_MG_BEAUTIFY_SHRINK_FACE);
        jniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_ENLARGE_EYE, Util.CURRENT_MG_BEAUTIFY_ENLARGE_EYE);
        jniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_THIN_FACE,Util.CURRENT_MG_BEAUTIFY_THIN_FACE);
        jniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_REMOVE_EYEBROW,Util.CURRENT_MG_BEAUTIFY_REMOVE_EYEBROW);
//        jniSdk.nativeSetBeautyParam2(BeaurifyJniSdk.MG_BEAUTIFY_EYEBROW,Util.CURRENT_MG_BEAUTIFY_EYEBROW,Util.CURRENT_MG_BEAUTIFY_EYEBROW_COLOR_R,Util.CURRENT_MG_BEAUTIFY_EYEBROW_COLOR_G,Util.CURRENT_MG_BEAUTIFY_EYEBROW_COLOR_B,
//                Util.DEFAULT_EYEBROW_TEMPLATE[Util.CURRENT_MG_BEAUTIFY_EYEBROW_TEMPLATE_INDEX],
//                Util.DEFAULT_EYEBROW_TEMPLATE_BASE[Util.CURRENT_MG_BEAUTIFY_EYEBROW_TEMPLATE_INDEX],
//                Util.DEFAULT_EYEBROW_KEYPOINTS[Util.CURRENT_MG_BEAUTIFY_EYEBROW_TEMPLATE_INDEX].mKeyPoints,
//                Util.DEFAULT_EYEBROW_KEYPOINTS[Util.CURRENT_MG_BEAUTIFY_EYEBROW_TEMPLATE_INDEX].mKeyPointsSize);
//        jniSdk.nativeSetBeautyParam2(BeaurifyJniSdk.MG_BEAUTIFY_CONTACT_LENS,Util.CURRENT_MG_BEAUTIFY_CONTACTLENS,0,0,0,
//                Util.DEFAULT_CONTACT_LENS_TEMPLATE[Util.CURRENT_MG_BEAUTIFY_CONTACT_LENS_TEMPLATE_INDEX],
//                null,null,0);
//        jniSdk.nativeSetBeautyParam2(BeaurifyJniSdk.MG_BEAUTIFY_LIP,Util.CURRENT_MG_BEAUTIFY_LIP,Util.CURRENT_MG_BEAUTIFY_LIP_COLOR_R,Util.CURRENT_MG_BEAUTIFY_LIP_COLOR_G,Util.CURRENT_MG_BEAUTIFY_LIP_COLOR_B,
//                null,null,null,0);
    }


    private void initImageHandle() {
        int width = mCameraManager.getPictureWidth();
        int height = mCameraManager.getPictureHeight();

        // 初始化美颜sdk
        BeaurifyJniSdk.imageInstance().nativeReleaseResources();
        BeaurifyJniSdk.imageInstance().nativeSetLogLevel(BeaurifyJniSdk.MG_LOG_LEVEL_DEBUG);
        BeaurifyJniSdk.imageInstance().nativeCreateBeautyHandle(mContext, width,
                height, 90, Util.MG_FPP_DENSEDETECTIONMODE_FULL_SIZE,
                ConUtil.getFileContent(mContext, R.raw.mgbeautify_1_2_4_model)
                , ConUtil.getFileContent(mContext, R.raw.detect_model),
                null);
        BeaurifyJniSdk.imageInstance().nativeDoneGLContext();
        initBeautyParam(IMAGE_INSTANCE);
    }

}
