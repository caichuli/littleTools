package com.megvii.beautify.model;

/**
 * Created by xiejiantao on 2017/7/18.
 */

public  class StaticsEvent {
  public String info;
}
