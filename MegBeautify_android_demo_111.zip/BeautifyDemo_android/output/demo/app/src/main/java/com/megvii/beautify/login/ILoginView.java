package com.megvii.beautify.login;

/**
 * Created by liyanshun on 2017/4/26.
 */

public interface ILoginView {
    void initComplete();
}
