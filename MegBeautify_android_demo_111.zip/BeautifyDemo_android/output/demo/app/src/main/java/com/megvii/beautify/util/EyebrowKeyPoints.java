package com.megvii.beautify.util;

import android.graphics.PointF;

public class EyebrowKeyPoints{
    public float[] mKeyPoints = new float[32];
    public int mKeyPointsSize = 16;
}
