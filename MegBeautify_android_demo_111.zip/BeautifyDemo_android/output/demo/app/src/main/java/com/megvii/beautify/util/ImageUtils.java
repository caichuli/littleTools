package com.megvii.beautify.util;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import static android.os.Environment.*;

/**
 * Created by wangshuai on 2018/4/17.
 */

public class ImageUtils {
    //保存文件到指定路径
    public static boolean saveImageToGallery(Context context, Bitmap bmp, String fileName) {
        // 首先保存图片
        String storePath = getExternalStorageDirectory().getAbsolutePath() + File.separator + "megvii_picture";
        File appDir = new File(storePath);
        if (!appDir.exists()) {
            appDir.mkdirs();
        }
        File file = new File(appDir, fileName);
        try {
            //file.mkdirs();
            FileOutputStream fos = new FileOutputStream(file.getAbsolutePath());
            //通过io流的方式来压缩保存图片
            boolean isSuccess = bmp.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.flush();
            fos.close();

            //把文件插入到系统图库
            //MediaStore.Images.Media.insertImage(context.getContentResolver(), file.getAbsolutePath(), fileName, null);

            //保存图片后发送广播通知更新数据库
            Uri uri = Uri.fromFile(file);
            context.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, uri));
            if (isSuccess) {
                return true;
            } else {
                return false;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static String saveNV21(byte[] data, String path, String name) {
        if (data == null)
            return null;

        File dir = new File(path);

        if (!dir.exists()) {
            if (!dir.mkdirs()) {
                return null;
            }
        }

        File file = new File(dir, name);
        FileOutputStream fos = null;
        String ret = null;
        try {
            fos = new FileOutputStream(file);
            fos.write(data);
            ret = file.getAbsolutePath();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (fos != null) fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return ret;
    }

}