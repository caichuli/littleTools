package com.megvii.beautify.app;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;

import com.megvii.beautify.util.FileUtil;
import com.megvii.beautify.util.Util;

import java.io.File;


/**
 * Created by liyanshun on 2017/4/24.
 */

public class MainApp extends Application {
    private static Context mContext;

    private static Handler mBackgroundHandler;
    private static HandlerThread mHandlerThread;


    public static Context getContext() {
        return mContext;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mContext = this.getApplicationContext();
        initFiles();

    }


    private void initFiles() {

        File cacheDir;

        Constant.sStickerDownloadPath = FileUtil.getZipPath(mContext,"sticker");
         cacheDir = new File( Constant.sStickerDownloadPath);
        if (!cacheDir.exists()) {
            cacheDir.mkdirs();
        }

        Constant.sFilterDownloadPath = FileUtil.getZipPath(mContext,"filter");
         cacheDir = new File( Constant.sFilterDownloadPath);
        if (!cacheDir.exists()) {
            cacheDir.mkdirs();
        }

        Util.mRandomFrestModelPath = FileUtil.getDiskCachePath(mContext) + "/random_forest_model/";
        cacheDir = new File( Util.mRandomFrestModelPath);
        if (!cacheDir.exists()) {
            cacheDir.mkdirs();
        }

    }

    public static Handler getBackgroundHandler() {
        return mBackgroundHandler;
    }

    public static void quitThread() {
        mHandlerThread.quit();
        mHandlerThread = null;
        mBackgroundHandler = null;
    }

    public static void createWorkerThread() {
        mHandlerThread = new HandlerThread("MainAppThread");
        mHandlerThread.start();
        mBackgroundHandler = new Handler(mHandlerThread.getLooper());
    }


}
