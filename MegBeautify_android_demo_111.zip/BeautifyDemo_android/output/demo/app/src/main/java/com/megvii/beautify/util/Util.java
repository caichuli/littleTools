package com.megvii.beautify.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PointF;

import com.megvii.beautify.R;
import com.megvii.beautify.jni.BeaurifyJniSdk;

import java.io.IOException;
import java.io.InputStream;
import java.util.Vector;

/**
 * Created by liyanshun on 2017/6/28.
 */

public class Util {
    public static final String[] KEYS = {"KEY_STICKER", "KEY_FILTER"};
    public static final int TYPE_STICKER = 0;
    public static final int TYPE_FILTER = 1;

    public static final int DEFAULT_OPTION_SUM = 6;                //默认选项个数

    public static final float DEFAULT_BEAUTIRY_VALUE = 0;
    public static final int   BEAUTIFY_TRANS_COEFFICIENT = 20;     //界面与sdk之间系数转换比

    //染眉默认值
    public static EyebrowKeyPoints[] DEFAULT_EYEBROW_KEYPOINTS = new EyebrowKeyPoints[DEFAULT_OPTION_SUM];
    public static final int[] DEFAULT_EYEBROW_COLOR = {43, 43, 43,
            80, 61, 55,
            94, 69, 74,
            76, 74, 86,
            120,87, 86,
            150,98, 69};
    public static  Bitmap[] DEFAULT_EYEBROW_TEMPLATE = new Bitmap[DEFAULT_OPTION_SUM];
    public static Bitmap[] DEFAULT_EYEBROW_TEMPLATE_BASE = new Bitmap[DEFAULT_OPTION_SUM];

    //美唇默认值
    public static final int[] DEAFULT_LIP_COLOR = {220, 27, 36,
            204, 76,125,
            233,125,125,
            254, 90,123,
            246, 51, 70,
            252,108, 94};

    //美瞳默认值
    public static  Bitmap[] DEFAULT_CONTACT_LENS_TEMPLATE = new Bitmap[DEFAULT_OPTION_SUM];
    public static  String[] DEFAULT_CONTACT_LENS_ASSERTS = {"contactlens/05_mt.png","contactlens/190_mt.png","contactlens/631_mt.png","contactlens/801_mt.png",
            "contactlens/803_mt.png","contactlens/8011_mt.png"};

    //美颜当前值
    public static float CURRENT_MG_BEAUTIFY_DENOISE = DEFAULT_BEAUTIRY_VALUE;
    public static float CURRENT_MG_BEAUTIFY_BRIGHTNESS = DEFAULT_BEAUTIRY_VALUE;
    public static float CURRENT_MG_BEAUTIFY_BRIGHTEN_EYE = DEFAULT_BEAUTIRY_VALUE;
    public static float CURRENT_MG_BEAUTIFY_TOOTH = DEFAULT_BEAUTIRY_VALUE;
    public static float CURRENT_MG_BEAUTIFY_ADD_PINK = DEFAULT_BEAUTIRY_VALUE;
    public static float CURRENT_MG_BEAUTIFY_REMOVE_SPECKLES = DEFAULT_BEAUTIRY_VALUE;
    public static float CURRENT_MG_BEAUTIFY_REMOVE_EYEBAGS = DEFAULT_BEAUTIRY_VALUE;
    public static float CURRENT_MG_BEAUTIFY_HIGH_NOSE_BRIDGE = DEFAULT_BEAUTIRY_VALUE;
    public static float CURRENT_MG_BEAUTIFY_UP_CHEEK = DEFAULT_BEAUTIRY_VALUE;
    public static float CURRENT_MG_BEAUTIFY_SKIN_BALANCE = DEFAULT_BEAUTIRY_VALUE;
    //祛斑模型
    public static byte[] mMuvarModel = null;
    public static String mRandomFrestModelPath = "";

    //美型当前值
    public static float CURRENT_MG_BEAUTIFY_SHRINK_FACE = DEFAULT_BEAUTIRY_VALUE;
    public static float CURRENT_MG_BEAUTIFY_ENLARGE_EYE = DEFAULT_BEAUTIRY_VALUE;
    public static float CURRENT_MG_BEAUTIFY_THIN_FACE = DEFAULT_BEAUTIRY_VALUE;
    public static float CURRENT_MG_BEAUTIFY_REMOVE_EYEBROW = DEFAULT_BEAUTIRY_VALUE;

    //美妆当前值
    // 染眉
    public static float CURRENT_MG_BEAUTIFY_EYEBROW = DEFAULT_BEAUTIRY_VALUE;
    public static int CURRENT_MG_BEAUTIFY_EYEBROW_COLOR_R = DEFAULT_EYEBROW_COLOR[0];
    public static int CURRENT_MG_BEAUTIFY_EYEBROW_COLOR_G = DEFAULT_EYEBROW_COLOR[1];
    public static int CURRENT_MG_BEAUTIFY_EYEBROW_COLOR_B = DEFAULT_EYEBROW_COLOR[2];
    public static int CURRENT_MG_BEAUTIFY_EYEBROW_TEMPLATE_INDEX = 0;
    //美唇
    public static float CURRENT_MG_BEAUTIFY_LIP = DEFAULT_BEAUTIRY_VALUE;
    //美瞳
    public static float CURRENT_MG_BEAUTIFY_CONTACTLENS = DEFAULT_BEAUTIRY_VALUE;
    public static int CURRENT_MG_BEAUTIFY_LIP_COLOR_R = DEAFULT_LIP_COLOR[0];
    public static int CURRENT_MG_BEAUTIFY_LIP_COLOR_G = DEAFULT_LIP_COLOR[1];
    public static int CURRENT_MG_BEAUTIFY_LIP_COLOR_B = DEAFULT_LIP_COLOR[2];
    public static int CURRENT_MG_BEAUTIFY_CONTACT_LENS_TEMPLATE_INDEX = 0;

    public static final int LandMarkPointSize = 1500;

    public volatile static boolean isStickerChanged;             //贴纸对象有变化
    public volatile static boolean isStickerParamInited = false; //贴纸对象初始化
    public volatile static String sCurrentStickerPath;

    public static boolean isDebuging = false;
    public static volatile boolean isDebugingLandMark = false;

    public volatile static boolean isFilterChanged;               //滤镜对象有变化
    public volatile static boolean isFilterParamInited = false;   //滤镜参数初始化
    public volatile static boolean isPostFilterChanged;
    public volatile static boolean isPostFilterParamInited = false;
    public volatile static String filterPath;

    public volatile static boolean isShowOriPic = false;    //预览是否显示原图

    public static boolean switchcamera = false;
    public static int switchcount = 0;

    public static final int MG_FPP_DENSEDETECTIONMODE_PREVIEW = 0;
    public static final int MG_FPP_DENSEDETECTIONMODE_FULL_SIZE = 1;




    public static final int MG_IMAGEMODE_GRAY = 0;      ///< 灰度图像

    public static final int MG_IMAGEMODE_BGR = 1;           ///< BGR图像

    public static final int MG_IMAGEMODE_NV21 = 2;         ///< YUV420（nv21）图像

    public static final int MG_IMAGEMODE_RGBA = 3;       ///< RGBA图像

    public static final int MG_IMAGEMODE_RGB = 4;        ///< RGB图像

    public static final int MG_IMAGEMODE_COUNT = 5;        ///< 支持图像总数


    static BeaurifyJniSdk beaurifyImageJniSdk;
    public static boolean isTestHAL = false;

    public static boolean isUseHighRes = false;

    static byte[] aligned;
    static byte[] outAligned;
    public synchronized static void testHALReleaseNV21Video(){
        if(beaurifyImageJniSdk!= null) {
            beaurifyImageJniSdk.nativeReleaseResources();
            beaurifyImageJniSdk = null;
        }
    }

    public synchronized static void testHALProcessNV21Video(Context context, byte[] input, byte[] output, int width, int height){

        int inW = width;
        int inH = height;
        width = BeaurifyJniSdk.getAlignSize(inW);
        height = BeaurifyJniSdk.getAlignSize(inH);
        if(beaurifyImageJniSdk == null){
            beaurifyImageJniSdk = BeaurifyJniSdk.videoInstance();
            beaurifyImageJniSdk.nativeCreateBeautyHandle(context, width,
                    height, 270, Util.MG_FPP_DENSEDETECTIONMODE_PREVIEW,
                    ConUtil.getFileContent(context, R.raw.mgbeautify_1_2_4_model)
                    , ConUtil.getFileContent(context, R.raw.detect_model),
                    ConUtil.getFileContent(context, R.raw.dense_model)
                    );

        }
        if(aligned == null || aligned.length!= width*height*3/2) {
            aligned = new byte[width * height * 3 / 2];
        }

        if(outAligned == null || outAligned.length!= width*height*3/2) {
            outAligned = new byte[width * height * 3 / 2];
        }
       // byte[] outAligned = new byte[width*height*3/2];

        BeaurifyJniSdk.alignNV21Data(input, inW, inH, aligned, width, height);

        beaurifyImageJniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_DENOISE, Util.CURRENT_MG_BEAUTIFY_DENOISE);
        beaurifyImageJniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_BRIGHTNESS, Util.CURRENT_MG_BEAUTIFY_BRIGHTNESS);
        beaurifyImageJniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_BRIGHTEN_EYE,Util.CURRENT_MG_BEAUTIFY_BRIGHTEN_EYE);
        beaurifyImageJniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_TOOTH,Util.CURRENT_MG_BEAUTIFY_TOOTH);
        beaurifyImageJniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_ADD_PINK, Util.CURRENT_MG_BEAUTIFY_ADD_PINK);

        beaurifyImageJniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_ENLARGE_EYE, Util.CURRENT_MG_BEAUTIFY_ENLARGE_EYE);
        beaurifyImageJniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_SHRINK_FACE, Util.CURRENT_MG_BEAUTIFY_SHRINK_FACE);

        beaurifyImageJniSdk.nativeProcessImageNV21(aligned, outAligned
                , width
                , height);

        BeaurifyJniSdk.deAlignNV21Data(output, inW,inH, outAligned, width, height);

    }

    public static void resetDefaultBeautifyParam(){
        CURRENT_MG_BEAUTIFY_DENOISE = DEFAULT_BEAUTIRY_VALUE;
        CURRENT_MG_BEAUTIFY_BRIGHTNESS = DEFAULT_BEAUTIRY_VALUE;
        CURRENT_MG_BEAUTIFY_BRIGHTEN_EYE = DEFAULT_BEAUTIRY_VALUE;
        CURRENT_MG_BEAUTIFY_TOOTH = DEFAULT_BEAUTIRY_VALUE;
        CURRENT_MG_BEAUTIFY_REMOVE_SPECKLES = DEFAULT_BEAUTIRY_VALUE;
        CURRENT_MG_BEAUTIFY_REMOVE_EYEBAGS = DEFAULT_BEAUTIRY_VALUE;
        CURRENT_MG_BEAUTIFY_HIGH_NOSE_BRIDGE = DEFAULT_BEAUTIRY_VALUE;
        CURRENT_MG_BEAUTIFY_UP_CHEEK = DEFAULT_BEAUTIRY_VALUE;
        CURRENT_MG_BEAUTIFY_SKIN_BALANCE = DEFAULT_BEAUTIRY_VALUE;
        CURRENT_MG_BEAUTIFY_ADD_PINK = DEFAULT_BEAUTIRY_VALUE;

        CURRENT_MG_BEAUTIFY_SHRINK_FACE = DEFAULT_BEAUTIRY_VALUE;
        CURRENT_MG_BEAUTIFY_ENLARGE_EYE = DEFAULT_BEAUTIRY_VALUE;
        CURRENT_MG_BEAUTIFY_THIN_FACE = DEFAULT_BEAUTIRY_VALUE;
        CURRENT_MG_BEAUTIFY_REMOVE_EYEBROW = DEFAULT_BEAUTIRY_VALUE;

        //美妆
        CURRENT_MG_BEAUTIFY_EYEBROW = DEFAULT_BEAUTIRY_VALUE;
        CURRENT_MG_BEAUTIFY_EYEBROW_COLOR_R = DEFAULT_EYEBROW_COLOR[0];
        CURRENT_MG_BEAUTIFY_EYEBROW_COLOR_G = DEFAULT_EYEBROW_COLOR[1];
        CURRENT_MG_BEAUTIFY_EYEBROW_COLOR_B = DEFAULT_EYEBROW_COLOR[2];
        CURRENT_MG_BEAUTIFY_EYEBROW_TEMPLATE_INDEX = 0;

        CURRENT_MG_BEAUTIFY_CONTACTLENS = DEFAULT_BEAUTIRY_VALUE;
        CURRENT_MG_BEAUTIFY_CONTACT_LENS_TEMPLATE_INDEX = 0;

        CURRENT_MG_BEAUTIFY_LIP = DEFAULT_BEAUTIRY_VALUE;
        CURRENT_MG_BEAUTIFY_LIP_COLOR_R = DEAFULT_LIP_COLOR[0];
        CURRENT_MG_BEAUTIFY_LIP_COLOR_G = DEAFULT_LIP_COLOR[1];
        CURRENT_MG_BEAUTIFY_LIP_COLOR_B = DEAFULT_LIP_COLOR[2];

    }

    public static void initTemplates(Context context){

        //加载美瞳模板资源
        for(int i=0;i<DEFAULT_OPTION_SUM;i++){
            InputStream is = null;
            try {
                is = context.getAssets().open(DEFAULT_CONTACT_LENS_ASSERTS[i]);
            } catch (IOException e) {
                e.printStackTrace();
            }
            DEFAULT_CONTACT_LENS_TEMPLATE[i] = BitmapFactory.decodeStream(is);
        }
//        //加载染眉模板资源
//        EyebrowKeyPoints eyebrowKeyPointsTemp = new EyebrowKeyPoints();
//        eyebrowKeyPointsTemp.mKeyPoints[0]  = 62 ; eyebrowKeyPointsTemp.mKeyPoints[1]  =78;
//        eyebrowKeyPointsTemp.mKeyPoints[2]  = 117; eyebrowKeyPointsTemp.mKeyPoints[3]  =52;
//        eyebrowKeyPointsTemp.mKeyPoints[4]  = 207; eyebrowKeyPointsTemp.mKeyPoints[5]  =41;
//        eyebrowKeyPointsTemp.mKeyPoints[6]  = 284; eyebrowKeyPointsTemp.mKeyPoints[7]  =35;
//        eyebrowKeyPointsTemp.mKeyPoints[8]  = 398; eyebrowKeyPointsTemp.mKeyPoints[9]  =53;
//        eyebrowKeyPointsTemp.mKeyPoints[10] = 285; eyebrowKeyPointsTemp.mKeyPoints[11] =70;
//        eyebrowKeyPointsTemp.mKeyPoints[12] = 208; eyebrowKeyPointsTemp.mKeyPoints[13] =80;
//        eyebrowKeyPointsTemp.mKeyPoints[14] = 110; eyebrowKeyPointsTemp.mKeyPoints[15] =92;
//
//        eyebrowKeyPointsTemp.mKeyPoints[16] = 56 ; eyebrowKeyPointsTemp.mKeyPoints[17] =53;
//        eyebrowKeyPointsTemp.mKeyPoints[18] = 170; eyebrowKeyPointsTemp.mKeyPoints[19] =35;
//        eyebrowKeyPointsTemp.mKeyPoints[20] = 247; eyebrowKeyPointsTemp.mKeyPoints[21] =41;
//        eyebrowKeyPointsTemp.mKeyPoints[22] = 337; eyebrowKeyPointsTemp.mKeyPoints[23] =52;
//        eyebrowKeyPointsTemp.mKeyPoints[24] = 392; eyebrowKeyPointsTemp.mKeyPoints[25] =78;
//        eyebrowKeyPointsTemp.mKeyPoints[26] = 344; eyebrowKeyPointsTemp.mKeyPoints[27] =92;
//        eyebrowKeyPointsTemp.mKeyPoints[28] = 246; eyebrowKeyPointsTemp.mKeyPoints[29] =80;
//        eyebrowKeyPointsTemp.mKeyPoints[30] = 169; eyebrowKeyPointsTemp.mKeyPoints[31] =70;

//        EyebrowKeyPoints eyebrowKeyPointsTemp = new EyebrowKeyPoints();
//        eyebrowKeyPointsTemp.mKeyPoints[0]  =  27; eyebrowKeyPointsTemp.mKeyPoints[1]  = 82;
//        eyebrowKeyPointsTemp.mKeyPoints[2]  =  76; eyebrowKeyPointsTemp.mKeyPoints[3]  = 49;
//        eyebrowKeyPointsTemp.mKeyPoints[4]  = 126; eyebrowKeyPointsTemp.mKeyPoints[5]  = 44;
//        eyebrowKeyPointsTemp.mKeyPoints[6]  = 172; eyebrowKeyPointsTemp.mKeyPoints[7]  = 47;
//        eyebrowKeyPointsTemp.mKeyPoints[8]  = 229; eyebrowKeyPointsTemp.mKeyPoints[9]  = 87;
//        eyebrowKeyPointsTemp.mKeyPoints[10] = 172; eyebrowKeyPointsTemp.mKeyPoints[11] = 72;
//        eyebrowKeyPointsTemp.mKeyPoints[12] = 127; eyebrowKeyPointsTemp.mKeyPoints[13] = 76;
//        eyebrowKeyPointsTemp.mKeyPoints[14] =  78; eyebrowKeyPointsTemp.mKeyPoints[15] = 87;
//
//        eyebrowKeyPointsTemp.mKeyPoints[16] = 269; eyebrowKeyPointsTemp.mKeyPoints[17] = 82;
//        eyebrowKeyPointsTemp.mKeyPoints[18] = 220; eyebrowKeyPointsTemp.mKeyPoints[19] = 49;
//        eyebrowKeyPointsTemp.mKeyPoints[20] = 170; eyebrowKeyPointsTemp.mKeyPoints[21] = 44;
//        eyebrowKeyPointsTemp.mKeyPoints[22] = 124; eyebrowKeyPointsTemp.mKeyPoints[23] = 47;
//        eyebrowKeyPointsTemp.mKeyPoints[24] =  67; eyebrowKeyPointsTemp.mKeyPoints[25] = 87;
//        eyebrowKeyPointsTemp.mKeyPoints[26] = 124; eyebrowKeyPointsTemp.mKeyPoints[27] = 72;
//        eyebrowKeyPointsTemp.mKeyPoints[28] = 169; eyebrowKeyPointsTemp.mKeyPoints[29] = 76;
//        eyebrowKeyPointsTemp.mKeyPoints[30] = 218; eyebrowKeyPointsTemp.mKeyPoints[31] = 87;

        EyebrowKeyPoints eyebrowKeyPointsTemp = new EyebrowKeyPoints();
        eyebrowKeyPointsTemp.mKeyPoints[0]  =  36; eyebrowKeyPointsTemp.mKeyPoints[1]  = 84;
        eyebrowKeyPointsTemp.mKeyPoints[2]  = 110; eyebrowKeyPointsTemp.mKeyPoints[3]  = 60;
        eyebrowKeyPointsTemp.mKeyPoints[4]  = 187; eyebrowKeyPointsTemp.mKeyPoints[5]  = 52;
        eyebrowKeyPointsTemp.mKeyPoints[6]  = 269; eyebrowKeyPointsTemp.mKeyPoints[7]  = 53;
        eyebrowKeyPointsTemp.mKeyPoints[8]  = 354; eyebrowKeyPointsTemp.mKeyPoints[9]  = 94;
        eyebrowKeyPointsTemp.mKeyPoints[10] = 266; eyebrowKeyPointsTemp.mKeyPoints[11] = 77;
        eyebrowKeyPointsTemp.mKeyPoints[12] = 188; eyebrowKeyPointsTemp.mKeyPoints[13] = 81;
        eyebrowKeyPointsTemp.mKeyPoints[14] = 112; eyebrowKeyPointsTemp.mKeyPoints[15] = 96;

        eyebrowKeyPointsTemp.mKeyPoints[16] = 100; eyebrowKeyPointsTemp.mKeyPoints[17] = 94;
        eyebrowKeyPointsTemp.mKeyPoints[18] = 185; eyebrowKeyPointsTemp.mKeyPoints[19] = 53;
        eyebrowKeyPointsTemp.mKeyPoints[20] = 267; eyebrowKeyPointsTemp.mKeyPoints[21] = 52;
        eyebrowKeyPointsTemp.mKeyPoints[22] = 344; eyebrowKeyPointsTemp.mKeyPoints[23] = 60;
        eyebrowKeyPointsTemp.mKeyPoints[24] = 415; eyebrowKeyPointsTemp.mKeyPoints[25] = 84;
        eyebrowKeyPointsTemp.mKeyPoints[26] = 342; eyebrowKeyPointsTemp.mKeyPoints[27] = 96;
        eyebrowKeyPointsTemp.mKeyPoints[28] = 266; eyebrowKeyPointsTemp.mKeyPoints[29] = 81;
        eyebrowKeyPointsTemp.mKeyPoints[30] = 188; eyebrowKeyPointsTemp.mKeyPoints[31] = 77;


        for(int i=0;i<DEFAULT_OPTION_SUM;i++){
            DEFAULT_EYEBROW_KEYPOINTS[i] = eyebrowKeyPointsTemp;
            InputStream is = null;
            try {
                is = context.getAssets().open("dashing_eyebrows.png");
            } catch (IOException e) {
                e.printStackTrace();
            }
            DEFAULT_EYEBROW_TEMPLATE[i] = BitmapFactory.decodeStream(is);

            try {
                is = context.getAssets().open("dashing_eyebrows_base.png");
            } catch (IOException e) {
                e.printStackTrace();
            }
            DEFAULT_EYEBROW_TEMPLATE_BASE[i] = BitmapFactory.decodeStream(is);
        }
    }
}
