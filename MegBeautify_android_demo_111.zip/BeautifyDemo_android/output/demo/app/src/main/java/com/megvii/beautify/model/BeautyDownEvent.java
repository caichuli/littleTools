package com.megvii.beautify.model;

/**
 * Created by xiejiantao on 2017/7/18.
 */

public  class BeautyDownEvent {
    public int status;
    public String titleChinese;
    public String titleEnglish;
}
