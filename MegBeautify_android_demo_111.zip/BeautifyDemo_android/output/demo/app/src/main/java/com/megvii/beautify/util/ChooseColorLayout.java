package com.megvii.beautify.util;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.IdRes;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;

import com.megvii.beautify.R;

/**
 * Created by liyanshun on 2017/7/7.
 */

public class ChooseColorLayout extends RelativeLayout {


    public interface OnChooseListener {
        void onChoose(int index);
    }

    RadioGroup mRadios;
    OnChooseListener mListener;

    public ChooseColorLayout(Context context) {
        super(context);
        init();
    }

    public ChooseColorLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();

    }

    public ChooseColorLayout(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        LayoutInflater layoutInflater = LayoutInflater.from(getContext());
        layoutInflater.inflate(R.layout.color_choose, this);
        mRadios = (RadioGroup) findViewById(R.id.color_choose_radio_group);
        mRadios.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                if (mListener == null) {
                    return;
                }
                switch (checkedId) {
                    case R.id.color_0:
                        mListener.onChoose(0);
                        break;
                    case R.id.color_1:
                        mListener.onChoose(1);
                        break;
                    case R.id.color_2:
                        mListener.onChoose(2);
                        break;
                    case R.id.color_3:
                        mListener.onChoose(3);
                        break;
                    case R.id.color_4:
                        mListener.onChoose(4);
                        break;
                    case R.id.color_5:
                        mListener.onChoose(5);
                        break;
                    default:
                        mListener.onChoose(0);
                }
            }
        });
    }


    public void setOnChooseListener(OnChooseListener mListener) {
        this.mListener = mListener;
    }

    public void setCheckIndex(int checkIndex) {
        RadioButton targetButton;
        switch (checkIndex) {

            case 1:
                targetButton = (RadioButton) mRadios.findViewById(R.id.color_1);
                break;
            case 2:
                targetButton = (RadioButton) mRadios.findViewById(R.id.color_2);
                break;
            case 3:
                targetButton = (RadioButton) mRadios.findViewById(R.id.color_3);
                break;
            case 4:
                targetButton = (RadioButton) mRadios.findViewById(R.id.color_4);
                break;
            case 5:
                targetButton = (RadioButton) mRadios.findViewById(R.id.color_5);
                break;
            case 0:
            default:
                targetButton = (RadioButton) mRadios.findViewById(R.id.color_0);
        }

        targetButton.setChecked(true);
    }

    public void setButtonColor(int index, int r, int g, int b){
        RadioButton targetButton;
        switch (index) {

            case 1:
                targetButton = (RadioButton) mRadios.findViewById(R.id.color_1);
                break;
            case 2:
                targetButton = (RadioButton) mRadios.findViewById(R.id.color_2);
                break;
            case 3:
                targetButton = (RadioButton) mRadios.findViewById(R.id.color_3);
                break;
            case 4:
                targetButton = (RadioButton) mRadios.findViewById(R.id.color_4);
                break;
            case 5:
                targetButton = (RadioButton) mRadios.findViewById(R.id.color_5);
                break;
            case 0:
            default:
                targetButton = (RadioButton) mRadios.findViewById(R.id.color_0);
        }
        targetButton.setBackgroundColor(Color.rgb(r,g,b));
    }

    public void setContactLens(int index){
        RadioButton targetButton;
        switch (index) {

            case 1:
                targetButton = (RadioButton) mRadios.findViewById(R.id.color_1);
                targetButton.setBackgroundResource(R.drawable._190_mt);
                break;
            case 2:
                targetButton = (RadioButton) mRadios.findViewById(R.id.color_2);
                targetButton.setBackgroundResource(R.drawable._631_mt);
                break;
            case 3:
                targetButton = (RadioButton) mRadios.findViewById(R.id.color_3);
                targetButton.setBackgroundResource(R.drawable._801_mt);
                break;
            case 4:
                targetButton = (RadioButton) mRadios.findViewById(R.id.color_4);
                targetButton.setBackgroundResource(R.drawable._803_mt);
                break;
            case 5:
                targetButton = (RadioButton) mRadios.findViewById(R.id.color_5);
                targetButton.setBackgroundResource(R.drawable._8011_mt);
                break;
            case 0:
            default:
                targetButton = (RadioButton) mRadios.findViewById(R.id.color_0);
                targetButton.setBackgroundResource(R.drawable._05_mt);
        }
    }

    public void setEyebrowTemplate(int index){
        RadioButton targetButton;
        switch (index) {

            case 1:
                targetButton = (RadioButton) mRadios.findViewById(R.id.color_1);
                targetButton.setBackgroundResource(R.drawable.dashing_eyebrows);
                break;
            case 2:
                targetButton = (RadioButton) mRadios.findViewById(R.id.color_2);
                targetButton.setBackgroundResource(R.drawable.dashing_eyebrows);
                break;
            case 3:
                targetButton = (RadioButton) mRadios.findViewById(R.id.color_3);
                targetButton.setBackgroundResource(R.drawable.dashing_eyebrows);
                break;
            case 4:
                targetButton = (RadioButton) mRadios.findViewById(R.id.color_4);
                targetButton.setBackgroundResource(R.drawable.dashing_eyebrows);
                break;
            case 5:
                targetButton = (RadioButton) mRadios.findViewById(R.id.color_5);
                targetButton.setBackgroundResource(R.drawable.dashing_eyebrows);
                break;
            case 0:
            default:
                targetButton = (RadioButton) mRadios.findViewById(R.id.color_0);
                targetButton.setBackgroundResource(R.drawable.dashing_eyebrows);
        }

    }
}
