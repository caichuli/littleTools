package com.megvii.beautify.app;

/**
 * Created by xiejiantao on 2017/7/18.
 */

public class Constant {
    public static final String BASE_URL = "https://facepp-content.oss-cn-hangzhou.aliyuncs.com/DownApp/stickerZIP/";
    public static String sStickerDownloadPath;//app初始化
    public static String sFilterDownloadPath;//app初始化
    public static String sTestVideoPath;//test初始化
}
