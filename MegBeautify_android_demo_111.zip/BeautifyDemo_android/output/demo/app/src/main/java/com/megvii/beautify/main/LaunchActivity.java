package com.megvii.beautify.main;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.megvii.beautify.BuildConfig;
import com.megvii.beautify.R;
import com.megvii.beautify.cameragl.CameraRender;
import com.megvii.beautify.login.LoadingActivity;
import com.megvii.beautify.login.LoginPresenter;
import com.megvii.beautify.jni.BeaurifyJniSdk;
import com.megvii.beautify.model.Model;
import com.megvii.beautify.util.ConUtil;
import com.megvii.beautify.util.FileUtil;
import com.megvii.beautify.util.Util;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.NodeList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;


public class LaunchActivity extends Activity {
    public static final int CAMERA_CODE = 100;
    public static final int GALLERY_CODE = 101;
    public static final int NV21_CODE = 102;

    private static final boolean IS_OFFLINE_DEBUG = false;

    private static DocumentBuilderFactory dbFactory = null;
    private static DocumentBuilder db = null;
    private static Document document = null;

    private LoginPresenter mPresenter;

    public String cameraPath;
    private Uri uriResult;
    private String[] mPermission = new String[]
            {Manifest.permission.WRITE_EXTERNAL_STORAGE
            , Manifest.permission.CAMERA
            , Manifest.permission.RECORD_AUDIO
            };
    private List<String> mNoPermission = new ArrayList<>();

    @BindView(R.id.btn_gallery)
    //Button btn_gallery;
    View btn_gallery;

    @BindView(R.id.btn_camera)
    View btn_camera;

    @BindView(R.id.btn_batch_proc)
    View btn_batch_proc;

    @BindView(R.id.iv_logo)
    View iv_logo;

    private BeaurifyJniSdk beaurifyJniSdk;

    private TextView mVersionView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launch);
        ButterKnife.bind(this);
        mVersionView = (TextView) findViewById(R.id.version);
        mVersionView.setText(BeaurifyJniSdk.preViewInstance().nativeGetBeautyVersion());
        mPresenter = new LoginPresenter();
        mPresenter.init();
        if(BuildConfig.BUILD_TYPE=="release"){
            btn_batch_proc.setVisibility(View.INVISIBLE);
        }
        if (IS_OFFLINE_DEBUG) {
            runDumpThread();
            runDumpNv21Thread();
        }
    }

    @OnClick(R.id.btn_camera)
    public void goCamera(View v) {
        Util.isTestHAL = false;
        requestCameraPerm(v);
        resetFilterParam();
        Util.resetDefaultBeautifyParam();
    }

    @OnClick(R.id.btn_gallery)
    public void goGallery(View v) {
//        requestGalleryPerm(GALLERY_CODE);
        requestGalleryPerm(NV21_CODE);
        resetFilterParam();
        Util.resetDefaultBeautifyParam();
    }

    @OnClick(R.id.iv_logo)
    public void goDebug(View v) {
//        requestGalleryPerm(GALLERY_CODE);
        CameraRender.mDebugConcurrent=true;
    }

    @OnClick(R.id.btn_batch_proc)
    public void batchprocess(View v) {
        beaurifyJniSdk = BeaurifyJniSdk.imageInstance();
        beaurifyJniSdk.nativeReleaseResources();
        beaurifyJniSdk.nativeSetLogLevel(beaurifyJniSdk.MG_LOG_LEVEL_DEBUG);
        beaurifyJniSdk.nativeCreateBeautyHandle(this, 0,
                0, 0, Util.MG_FPP_DENSEDETECTIONMODE_FULL_SIZE,
                ConUtil.getFileContent(this, R.raw.mgbeautify_1_2_4_model)
                , ConUtil.getFileContent(this, R.raw.detect_model),
                ConUtil.getFileContent(this,R.raw.dense_model)
        );
        beaurifyJniSdk.nativeDoneGLContext();
        //初始化美瞳，染眉模板
        Util.initTemplates(getApplicationContext());
        //读取配置文件，设置参数
        readParamFileAndSet("file:///sdcard/megvii_batch_proc/BeautifyParams.xml");

        onFolderBatchProcess("/sdcard/megvii_batch_proc/images");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (beaurifyJniSdk!= null) {
            beaurifyJniSdk.nativeReleaseResources();
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        if (requestCode == CAMERA_CODE) {
            if (grantResults[0] != PackageManager.PERMISSION_GRANTED) {// Permission Granted
                Toast.makeText(this, R.string.err_camera, Toast.LENGTH_SHORT);
            } else {
                startPreview();
            }
        } else if (requestCode == GALLERY_CODE
                || requestCode == NV21_CODE) {
            if (grantResults[0] != PackageManager.PERMISSION_GRANTED) {// Permission Granted
                Toast.makeText(this, R.string.err_gallery, Toast.LENGTH_SHORT);
            } else {
                openGalleryActivity(requestCode);
            }
        }
    }

    public void requestGalleryPerm(int  code) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
                PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission
                    .WRITE_EXTERNAL_STORAGE}, code);
        } else {
            openGalleryActivity(code);
        }
    }


    public void requestCameraPerm(View view) {
        mNoPermission.clear();
        for (int i = 0; i < mPermission.length; i++) {
            if (ContextCompat.checkSelfPermission(this, mPermission[i]) != PackageManager
                    .PERMISSION_GRANTED) {
                mNoPermission.add(mPermission[i]);
            }
        }
        if (mNoPermission.isEmpty()) {
            startPreview();
        } else {
            String[] permission = mNoPermission.toArray(new String[mNoPermission.size()]);
            ActivityCompat.requestPermissions(this, permission, CAMERA_CODE);
        }
    }



    private void openGalleryActivity(int code) {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, code);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.i("wangshuai", "onActivityResult" + resultCode + data + cameraPath);
        switch (requestCode) {
            case GALLERY_CODE:
            case NV21_CODE:
                if (resultCode == Activity.RESULT_OK) {
                    uriResult = data.getData();
                    startImage(requestCode);
                }
                break;
            default:
                break;
        }
    }

    private void startPreview(){
        Intent intent = new Intent();
        intent.setClass(this, LoadingActivity.class);
        startActivity(intent);
    }
    public void startImage(int code) {
//        final ProgressDialog dialog = new ProgressDialog(MainActivity.this);
//        dialog.show();
        Intent intent = new Intent(this, PostProcessActivity.class);
        intent.putExtra("imgurl", uriResult);
        intent.putExtra("image_type", code);
        startActivity(intent);

    }

    private void resetFilterParam(){
        //滤镜处理
        Model.filterPosition = 0;
        Util.filterPath = "";
    }


    private Bitmap  mInBmp, mOutBmp;
    public void onFolderBatchProcess(final String folder){
        new Thread(new Runnable() {
            @Override
            public void run() {
                File parent = new File(folder);
                final String[] children = parent.list();
                if(children != null) {
                    for (int index = 0; index < children.length; index++) {
                        Log.i(this.getClass().getSimpleName(), "batch: " + folder + File.separator + children[index]);
                        if (mInBmp != null && !mInBmp.isRecycled()) {
                            mInBmp.recycle();
                            mInBmp = null;
                        }
                        mInBmp = ConUtil.getImage(folder + File.separator + children[index]);
                        if(mInBmp==null){
                            continue;
                        }

                        if (mOutBmp != null && !mOutBmp.isRecycled()) {
                            mOutBmp.recycle();
                            mOutBmp = null;
                        }
                        mOutBmp = mInBmp.copy(mInBmp.getConfig(), mInBmp.isMutable());
                        showToast("Start processing: " + children[index]);
                        batchProcessImage(mInBmp, mOutBmp);
                        saveBitmap(children[index], mOutBmp);
                    }
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showToast("Batch done!");
                    }
                });

            }
        }).start();
    }

    private void showToast(final String content) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(LaunchActivity.this, content, Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void saveBitmap(String fileName, Bitmap resultBmp) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
                PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission
                    .WRITE_EXTERNAL_STORAGE}, PostProcessActivity.GALLERY_CODE);
        } else {
            saveResultImage(fileName, resultBmp);
        }
    }


   private void saveResultImage(String  fileName, Bitmap resultBmp){
       StringBuffer strPrefix = new StringBuffer((fileName.substring(0 , fileName.length() - 4)));
       strPrefix.append("_");
       strPrefix.append("after");
       strPrefix.append(".jpg");
       ConUtil.saveBitmap(LaunchActivity.this, resultBmp, strPrefix.toString());
   }

    public void batchProcessImage(Bitmap srcImage,Bitmap dstImage) {

        long startTime = System.currentTimeMillis();
        beaurifyJniSdk.nativeShareGLContext();
        beaurifyJniSdk.nativeReset(srcImage.getWidth(),srcImage.getHeight(),0);   //批处理送入图片方向都是0
        beaurifyJniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_DENOISE, 2);
        beaurifyJniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_BRIGHTNESS, Util.CURRENT_MG_BEAUTIFY_BRIGHTNESS);
        beaurifyJniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_BRIGHTEN_EYE,Util.CURRENT_MG_BEAUTIFY_BRIGHTEN_EYE);
        beaurifyJniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_TOOTH,Util.CURRENT_MG_BEAUTIFY_TOOTH);
        //祛斑
        if((Util.CURRENT_MG_BEAUTIFY_REMOVE_SPECKLES-0.0f)>0.01){
            //拷贝随机森林树至cache目录
            String outPathName = Util.mRandomFrestModelPath+"trained_rt_model.dat";
            FileUtil.copyDataFromRaw2Path(this,"trained_rt_model.dat",outPathName);
            beaurifyJniSdk.nativeSetBeautyRemoveSpeckles(Util.CURRENT_MG_BEAUTIFY_REMOVE_SPECKLES,ConUtil.getFileContent(this, R.raw.muvar),Util.mRandomFrestModelPath);
        }
        beaurifyJniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_REMOVE_EYEBAGS, Util.CURRENT_MG_BEAUTIFY_REMOVE_EYEBAGS);
        beaurifyJniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_HIGH_NOSEBRIDGE, Util.CURRENT_MG_BEAUTIFY_HIGH_NOSE_BRIDGE);
        beaurifyJniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_UPCHEEK,Util.CURRENT_MG_BEAUTIFY_UP_CHEEK);
        beaurifyJniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_SKIN_BALANCE, Util.CURRENT_MG_BEAUTIFY_SKIN_BALANCE);
        beaurifyJniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_ADD_PINK, Util.CURRENT_MG_BEAUTIFY_ADD_PINK);

        beaurifyJniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_SHRINK_FACE, Util.CURRENT_MG_BEAUTIFY_SHRINK_FACE);
        beaurifyJniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_ENLARGE_EYE, Util.CURRENT_MG_BEAUTIFY_ENLARGE_EYE);
        beaurifyJniSdk.nativeSetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_THIN_FACE, Util.CURRENT_MG_BEAUTIFY_THIN_FACE);
        beaurifyJniSdk.nativeSetBeautyParam(beaurifyJniSdk.MG_BEAUTIFY_REMOVE_EYEBROW,Util.CURRENT_MG_BEAUTIFY_REMOVE_EYEBROW);

        beaurifyJniSdk.nativeSetBeautyParam2(beaurifyJniSdk.MG_BEAUTIFY_EYEBROW,Util.CURRENT_MG_BEAUTIFY_EYEBROW,Util.CURRENT_MG_BEAUTIFY_EYEBROW_COLOR_R,Util.CURRENT_MG_BEAUTIFY_EYEBROW_COLOR_G,Util.CURRENT_MG_BEAUTIFY_EYEBROW_COLOR_B,
                Util.DEFAULT_EYEBROW_TEMPLATE[Util.CURRENT_MG_BEAUTIFY_EYEBROW_TEMPLATE_INDEX],
                Util.DEFAULT_EYEBROW_TEMPLATE_BASE[Util.CURRENT_MG_BEAUTIFY_EYEBROW_TEMPLATE_INDEX],
                Util.DEFAULT_EYEBROW_KEYPOINTS[Util.CURRENT_MG_BEAUTIFY_EYEBROW_TEMPLATE_INDEX].mKeyPoints,
                Util.DEFAULT_EYEBROW_KEYPOINTS[Util.CURRENT_MG_BEAUTIFY_EYEBROW_TEMPLATE_INDEX].mKeyPointsSize);


        beaurifyJniSdk.nativeSetBeautyParam2(beaurifyJniSdk.MG_BEAUTIFY_CONTACT_LENS,Util.CURRENT_MG_BEAUTIFY_CONTACTLENS,0,0,0,Util.DEFAULT_CONTACT_LENS_TEMPLATE[Util.CURRENT_MG_BEAUTIFY_CONTACT_LENS_TEMPLATE_INDEX],null,null,0);
        beaurifyJniSdk.nativeSetBeautyParam2(beaurifyJniSdk.MG_BEAUTIFY_LIP,Util.CURRENT_MG_BEAUTIFY_LIP,Util.CURRENT_MG_BEAUTIFY_LIP_COLOR_R,Util.CURRENT_MG_BEAUTIFY_LIP_COLOR_G,Util.CURRENT_MG_BEAUTIFY_LIP_COLOR_B,null,null,null,0);


        beaurifyJniSdk.nativeProcessImage(srcImage, dstImage);
        beaurifyJniSdk.nativeDoneGLContext();

        long endTime = System.currentTimeMillis();
        Log.i("batchProcessImage", "batchProcessImage: "+(endTime - startTime)+" ms");
    }

    static{
        try {
            dbFactory = DocumentBuilderFactory.newInstance();
            db = dbFactory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
    }

    private void readParamFileAndSet(final String ParamFile){
        float [] params = new float[10]; //8个参数容器
        try{
            //URI uri = URI.create(ParamFile);

            //将给定 URI 的内容解析为一个 XML 文档,并返回Document对象
            document = db.parse(ParamFile);
            //按文档顺序返回包含在文档中且具有给定标记名称的所有 Element 的 NodeList
            NodeList paramList = document.getElementsByTagName("param");
            //遍历param
            for(int i=0;i<paramList.getLength();i++){
                //获取第i个param结点
                org.w3c.dom.Node node = paramList.item(i);
                //获取第i个book的所有属性
                NamedNodeMap namedNodeMap = node.getAttributes();
                //获取已知名为id的属性值
                String id = namedNodeMap.getNamedItem("id").getTextContent();


                //获取param结点的子节点,包含了Test类型的换行
                NodeList cList = node.getChildNodes();//System.out.println(cList.getLength());9
                String confidense = "";
                String color = "";
                String type = "";

                //将一个confidense里面的属性加入数组
                for(int j=0;j<cList.getLength();j++){
                    org.w3c.dom.Node cNode = cList.item(j);
                    String nodeName = cNode.getNodeName();
                    switch(nodeName){
                        case "coefficient":
                            confidense = cNode.getTextContent();
                            break;
                        case "color":
                            color = cNode.getTextContent();
                            break;
                        case "type":
                            type = cNode.getTextContent();
                            break;
                    }
                }
                switch(id){
                    case "denoise":
                        Util.CURRENT_MG_BEAUTIFY_DENOISE = (new Float(confidense));
                        break;
                    case "brightness":
                        Util.CURRENT_MG_BEAUTIFY_BRIGHTNESS = (new Float(confidense));
                        break;
                    case "brightness_eye":
                        Util.CURRENT_MG_BEAUTIFY_BRIGHTEN_EYE = (new Float(confidense));
                        break;
                    case "teeth":
                        Util.CURRENT_MG_BEAUTIFY_TOOTH = (new Float(confidense));
                        break;
                    case "pink":
                        Util.CURRENT_MG_BEAUTIFY_ADD_PINK = (new Float(confidense));
                        break;
                    case "remove_speckles":
                        Util.CURRENT_MG_BEAUTIFY_REMOVE_SPECKLES = (new Float(confidense));
                        break;
                    case "remove_eyebags":
                        Util.CURRENT_MG_BEAUTIFY_REMOVE_EYEBAGS = (new Float(confidense));
                        break;
                    case "high_nosebridge":
                        Util.CURRENT_MG_BEAUTIFY_HIGH_NOSE_BRIDGE = (new Float(confidense));
                        break;
                    case "up_cheek":
                        Util.CURRENT_MG_BEAUTIFY_UP_CHEEK = (new Float(confidense));
                        break;
                    case "skin_balance":
                        Util.CURRENT_MG_BEAUTIFY_SKIN_BALANCE = (new Float(confidense));
                        break;
                    case "small_face":
                        Util.CURRENT_MG_BEAUTIFY_SHRINK_FACE = (new Float(confidense));
                        break;
                    case "enlarge_eye":
                        Util.CURRENT_MG_BEAUTIFY_ENLARGE_EYE = (new Float(confidense));
                        break;
                    case "thin_face":
                        Util.CURRENT_MG_BEAUTIFY_THIN_FACE = (new Float(confidense));
                        break;
                    case "remove_eyebrow":
                        Util.CURRENT_MG_BEAUTIFY_REMOVE_EYEBROW = (new Float(confidense));
                        break;
                    case "eyebrow": {
                        Util.CURRENT_MG_BEAUTIFY_EYEBROW = (new Float(confidense));
                        int colorIndex = (new Integer(color));
                        Util.CURRENT_MG_BEAUTIFY_EYEBROW_COLOR_R = Util.DEFAULT_EYEBROW_COLOR[colorIndex * 3];
                        Util.CURRENT_MG_BEAUTIFY_EYEBROW_COLOR_G = Util.DEFAULT_EYEBROW_COLOR[colorIndex * 3 + 1];
                        Util.CURRENT_MG_BEAUTIFY_EYEBROW_COLOR_B = Util.DEFAULT_EYEBROW_COLOR[colorIndex * 3 + 2];
                        Util.CURRENT_MG_BEAUTIFY_EYEBROW_TEMPLATE_INDEX = (new Integer(type));
                        break;
                    }
                    case "lip": {
                        Util.CURRENT_MG_BEAUTIFY_LIP = (new Float(confidense));
                        int colorIndex = (new Integer(color));
                        Util.CURRENT_MG_BEAUTIFY_LIP_COLOR_R = Util.DEAFULT_LIP_COLOR[colorIndex*3];
                        Util.CURRENT_MG_BEAUTIFY_LIP_COLOR_G = Util.DEAFULT_LIP_COLOR[colorIndex*3 + 1];
                        Util.CURRENT_MG_BEAUTIFY_LIP_COLOR_B = Util.DEAFULT_LIP_COLOR[colorIndex*3 + 2];
                        break;
                    }
                    case "contact_lens": {
                        Util.CURRENT_MG_BEAUTIFY_CONTACTLENS = (new Float(confidense));
                        Util.CURRENT_MG_BEAUTIFY_CONTACT_LENS_TEMPLATE_INDEX = (new Integer(type));
                        break;
                    }
                }

            }

        }catch (Exception e){
            Log.i("readParamFileAndSet","parse BeautifyParams.xml error,use default date");
        }

    }

    private void runDumpThread() {
        new Thread() {
            @Override
            public void run() {
                String dirPath = "/sdcard/megvii/camera/";
                File dir = new File(dirPath);
                String tag = "DumpProc";
                if (!dir.exists()) {
                    Log.e(tag, dirPath + " doesn't exist!");
                    return;
                }
                File[] files = dir.listFiles(new FileFilter() {
                    @Override
                    public boolean accept(File pathname) {
                        return pathname.getName().endsWith(".rgba");
                    }
                });

                int width = 1024;
                int height = 768;

                if (files == null || files.length == 0) {
                    return;
                }
                for(File rgbaFile: files) {
                    String fileName = rgbaFile.getName().replace(".rgba", "");
                    String[] splitStrs = fileName.split("_");
                    if (splitStrs.length == 3) {
                        String[] splitStrs2 = splitStrs[splitStrs.length - 1].split("x");
                        if (splitStrs2.length == 2) {
                            width = Integer.parseInt(splitStrs2[0]);
                            height = Integer.parseInt(splitStrs2[1]);
                        }
                    }

                    ConUtil.convertDumpFileToJpeg(LaunchActivity.this, rgbaFile, width, height);
                }

                Log.e(tag, dirPath + " dump end!");
            }
        }.start();
    }

    private void runDumpNv21Thread() {
        new Thread() {
            @Override
            public void run() {
                String dirPath = "/sdcard/megvii/camera/";
                File dir = new File(dirPath);
                String tag = "DumpProc";
                if (!dir.exists()) {
                    Log.e(tag, dirPath + " doesn't exist!");
                    return;
                }
                File[] files = dir.listFiles(new FileFilter() {
                    @Override
                    public boolean accept(File pathname) {
                        return pathname.getName().endsWith(".nv21");
                    }
                });

                int width = 1024;
                int height = 768;

                if (files == null || files.length == 0) {
                    return;
                }
                for(File rgbaFile: files) {
                    String fileName = rgbaFile.getName().replace(".nv21", "");
                    String[] splitStrs = fileName.split("_");
                    if (splitStrs.length == 3) {
                        String[] splitStrs2 = splitStrs[splitStrs.length - 1].split("x");
                        if (splitStrs2.length == 2) {
                            width = Integer.parseInt(splitStrs2[0]);
                            height = Integer.parseInt(splitStrs2[1]);
                        }
                    }

                    ConUtil.convertDumpNv21FileToJpeg(LaunchActivity.this, rgbaFile, width, height);
                }

                Log.e(tag, dirPath + " dump end!");
            }
        }.start();
    }

}
