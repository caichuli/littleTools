package com.megvii.beautify.main.fragment;

public interface FragmentCallBack {

    void onFragmantChanged(int type, int value);
    void onListFragmentChanged();
}
