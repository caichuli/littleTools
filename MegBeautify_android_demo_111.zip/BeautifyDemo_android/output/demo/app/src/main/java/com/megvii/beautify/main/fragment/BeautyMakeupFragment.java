package com.megvii.beautify.main.fragment;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SeekBar;

import com.megvii.beautify.R;
import com.megvii.beautify.jni.BeaurifyJniSdk;
import com.megvii.beautify.ui.SeekBarRelativeLayout;
import com.megvii.beautify.util.ChooseColorLayout;
import com.megvii.beautify.util.FiveChooseView;
import com.megvii.beautify.util.Util;

import butterknife.BindView;

/**
 * Created by liyanshun on 2017/7/7.
 */

public class BeautyMakeupFragment extends BaseFragment {
    @BindView(R.id.eyebrow)
    SeekBarRelativeLayout eyebrow;
    @BindView(R.id.eyebrow_color)
    ChooseColorLayout eyebrow_color;
    @BindView(R.id.eyebrow_template)
    ChooseColorLayout eyebrow_template;

    @BindView(R.id.lip)
    SeekBarRelativeLayout lip;
    @BindView(R.id.lip_color)
    ChooseColorLayout lip_color;

    @BindView(R.id.contactlens)
    SeekBarRelativeLayout contactlens;
    @BindView(R.id.contactlens_template)
    ChooseColorLayout contactlens_template;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.beauty_makeup_fragment, null);
        return null;
    }

    private SeekBar.OnSeekBarChangeListener mOnSeekBarChangeListenerEyeBrow = new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
            int progress = seekBar.getProgress();
            SetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_EYEBROW,progress);
        }
    };

    private SeekBar.OnSeekBarChangeListener mOnSeekBarChangeListenerContactLens = new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
            int progress = seekBar.getProgress();
            SetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_CONTACT_LENS,progress);
        }
    };

    private SeekBar.OnSeekBarChangeListener mOnSeekBarChangeListenerLip = new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
            int progress = seekBar.getProgress();
            SetBeautyParam(BeaurifyJniSdk.MG_BEAUTIFY_LIP,progress);
        }
    };


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Log.i("xie", "xie shape create");
        title.setText(R.string.makeup);
        eyebrow.setmTitle(R.string.eyebrow);
        lip.setmTitle(R.string.lip);
        contactlens.setmTitle(R.string.contactlens);

        eyebrow.setOnSeekBarChangeListener(mOnSeekBarChangeListenerEyeBrow);
        contactlens.setOnSeekBarChangeListener(mOnSeekBarChangeListenerContactLens);
        lip.setOnSeekBarChangeListener(mOnSeekBarChangeListenerLip);

        eyebrow.setProgress((int) (Util.CURRENT_MG_BEAUTIFY_EYEBROW * Util.BEAUTIFY_TRANS_COEFFICIENT));
        contactlens.setProgress((int) (Util.CURRENT_MG_BEAUTIFY_CONTACTLENS* Util.BEAUTIFY_TRANS_COEFFICIENT));
        lip.setProgress((int) (Util.CURRENT_MG_BEAUTIFY_LIP * Util.BEAUTIFY_TRANS_COEFFICIENT));

        SetDefaultColor();
        SetColorParam();

    }

    private void SetDefaultColor(){
        for(int i=0;i<6;i++){
            eyebrow_color.setButtonColor(i,Util.DEFAULT_EYEBROW_COLOR[i*3],Util.DEFAULT_EYEBROW_COLOR[i*3+1],Util.DEFAULT_EYEBROW_COLOR[i*3+2]);
            eyebrow_template.setEyebrowTemplate(i);
            contactlens_template.setContactLens(i);
            lip_color.setButtonColor(i,Util.DEAFULT_LIP_COLOR[i*3],Util.DEAFULT_LIP_COLOR[i*3+1],Util.DEAFULT_LIP_COLOR[i*3+2]);
        }

    }

    private void setDefaultValue(ChooseColorLayout colorLayout, int index) {
        colorLayout.setCheckIndex(index);
    }

    private void SetBeautyParam(int beautyType, int progress) {
        float chooseValue = (float) progress / Util.BEAUTIFY_TRANS_COEFFICIENT;
        switch (beautyType) {
            case BeaurifyJniSdk.MG_BEAUTIFY_EYEBROW:
                BeaurifyJniSdk.preViewInstance().nativeSetBeautyParam2(beautyType, chooseValue,Util.CURRENT_MG_BEAUTIFY_EYEBROW_COLOR_R,Util.CURRENT_MG_BEAUTIFY_EYEBROW_COLOR_G,Util.CURRENT_MG_BEAUTIFY_EYEBROW_COLOR_B,
                        Util.DEFAULT_EYEBROW_TEMPLATE[Util.CURRENT_MG_BEAUTIFY_EYEBROW_TEMPLATE_INDEX],
                        Util.DEFAULT_EYEBROW_TEMPLATE_BASE[Util.CURRENT_MG_BEAUTIFY_EYEBROW_TEMPLATE_INDEX],
                        Util.DEFAULT_EYEBROW_KEYPOINTS[Util.CURRENT_MG_BEAUTIFY_EYEBROW_TEMPLATE_INDEX].mKeyPoints,
                        Util.DEFAULT_EYEBROW_KEYPOINTS[Util.CURRENT_MG_BEAUTIFY_EYEBROW_TEMPLATE_INDEX].mKeyPointsSize);
                if (Math.abs(Util.CURRENT_MG_BEAUTIFY_EYEBROW - chooseValue) > 0.1) {
                    Util.CURRENT_MG_BEAUTIFY_EYEBROW = chooseValue;
                    if (null != callback) {
                        callback.onFragmantChanged(0, 0);
                    }
                }
                break;
            case BeaurifyJniSdk.MG_BEAUTIFY_CONTACT_LENS:
                BeaurifyJniSdk.preViewInstance().nativeSetBeautyParam2(beautyType, chooseValue,0,0,0,Util.DEFAULT_CONTACT_LENS_TEMPLATE[Util.CURRENT_MG_BEAUTIFY_CONTACT_LENS_TEMPLATE_INDEX],
                        null,null,0);
                if (Math.abs(Util.CURRENT_MG_BEAUTIFY_CONTACTLENS - chooseValue) > 0.1) {
                    Util.CURRENT_MG_BEAUTIFY_CONTACTLENS = chooseValue;
                    if (null != callback) {
                        callback.onFragmantChanged(0, 0);
                    }
                }
                break;
            case BeaurifyJniSdk.MG_BEAUTIFY_LIP:
                BeaurifyJniSdk.preViewInstance().nativeSetBeautyParam2(beautyType, chooseValue,Util.CURRENT_MG_BEAUTIFY_LIP_COLOR_R,Util.CURRENT_MG_BEAUTIFY_LIP_COLOR_G,Util.CURRENT_MG_BEAUTIFY_LIP_COLOR_B,
                        null,null,null,0);
                if (Math.abs(Util.CURRENT_MG_BEAUTIFY_LIP- chooseValue) > 0.1) {
                    Util.CURRENT_MG_BEAUTIFY_LIP = chooseValue;
                    if (null != callback) {
                        callback.onFragmantChanged(0, 0);
                    }
                }
                break;
            default:
                break;
        }
    }

    private void SetColorParam(){
        eyebrow_color.setOnChooseListener(new ChooseColorLayout.OnChooseListener() {
            @Override
            public void onChoose(int index) {
                //setDefaultValue(eyebrow_color,index);
                BeaurifyJniSdk.preViewInstance().nativeSetBeautyParam2(BeaurifyJniSdk.MG_BEAUTIFY_EYEBROW, Util.CURRENT_MG_BEAUTIFY_EYEBROW,Util.DEFAULT_EYEBROW_COLOR[index*3],Util.DEFAULT_EYEBROW_COLOR[index*3+1],Util.DEFAULT_EYEBROW_COLOR[index*3+2],
                        Util.DEFAULT_EYEBROW_TEMPLATE[Util.CURRENT_MG_BEAUTIFY_EYEBROW_TEMPLATE_INDEX],
                        Util.DEFAULT_EYEBROW_TEMPLATE_BASE[Util.CURRENT_MG_BEAUTIFY_EYEBROW_TEMPLATE_INDEX],
                        Util.DEFAULT_EYEBROW_KEYPOINTS[Util.CURRENT_MG_BEAUTIFY_EYEBROW_TEMPLATE_INDEX].mKeyPoints,
                        Util.DEFAULT_EYEBROW_KEYPOINTS[Util.CURRENT_MG_BEAUTIFY_EYEBROW_TEMPLATE_INDEX].mKeyPointsSize);
                if(Util.CURRENT_MG_BEAUTIFY_EYEBROW_COLOR_R != Util.DEFAULT_EYEBROW_COLOR[index*3] ||
                        Util.CURRENT_MG_BEAUTIFY_EYEBROW_COLOR_G != Util.DEFAULT_EYEBROW_COLOR[index*3+1]  ||
                        Util.CURRENT_MG_BEAUTIFY_EYEBROW_COLOR_B != Util.DEFAULT_EYEBROW_COLOR[index*3 +2]) {
                            Util.CURRENT_MG_BEAUTIFY_EYEBROW_COLOR_R = Util.DEFAULT_EYEBROW_COLOR[index*3];
                            Util.CURRENT_MG_BEAUTIFY_EYEBROW_COLOR_G = Util.DEFAULT_EYEBROW_COLOR[index*3+1];
                            Util.CURRENT_MG_BEAUTIFY_EYEBROW_COLOR_B = Util.DEFAULT_EYEBROW_COLOR[index*3+2];
                            if(null != callback ){
                                callback.onFragmantChanged(0,0);
                            }
                        }
                }
        });

        eyebrow_template.setOnChooseListener(new ChooseColorLayout.OnChooseListener() {
            @Override
            public void onChoose(int index) {
                //setDefaultValue(eyebrow_template,index);
                BeaurifyJniSdk.preViewInstance().nativeSetBeautyParam2(BeaurifyJniSdk.MG_BEAUTIFY_EYEBROW, Util.CURRENT_MG_BEAUTIFY_EYEBROW,Util.DEFAULT_EYEBROW_COLOR[index*3],Util.DEFAULT_EYEBROW_COLOR[index*3+1],Util.DEFAULT_EYEBROW_COLOR[index*3+2],
                        Util.DEFAULT_EYEBROW_TEMPLATE[index],
                        Util.DEFAULT_EYEBROW_TEMPLATE_BASE[index],
                        Util.DEFAULT_EYEBROW_KEYPOINTS[index].mKeyPoints,
                        Util.DEFAULT_EYEBROW_KEYPOINTS[index].mKeyPointsSize);
                if(Util.CURRENT_MG_BEAUTIFY_EYEBROW_TEMPLATE_INDEX != index) {
                    Util.CURRENT_MG_BEAUTIFY_EYEBROW_TEMPLATE_INDEX = index;
                    if(null != callback ){
                        callback.onFragmantChanged(0,0);
                    }
                }
            }
        });

        contactlens_template.setOnChooseListener(new ChooseColorLayout.OnChooseListener() {
            @Override
            public void onChoose(int index) {
                setDefaultValue(contactlens_template,index);
                BeaurifyJniSdk.preViewInstance().nativeSetBeautyParam2(BeaurifyJniSdk.MG_BEAUTIFY_CONTACT_LENS, Util.CURRENT_MG_BEAUTIFY_CONTACTLENS,0,0,0,
                        Util.DEFAULT_CONTACT_LENS_TEMPLATE[index],
                        null,null,0);
                if(Util.CURRENT_MG_BEAUTIFY_CONTACT_LENS_TEMPLATE_INDEX != index ) {
                            Util.CURRENT_MG_BEAUTIFY_CONTACT_LENS_TEMPLATE_INDEX = index;
                            if(null != callback ){
                                callback.onFragmantChanged(0,0);
                            }
                }
            }
        });
        lip_color.setOnChooseListener(new ChooseColorLayout.OnChooseListener() {
            @Override
            public void onChoose(int index) {
                setDefaultValue(lip_color, index);
                BeaurifyJniSdk.preViewInstance().nativeSetBeautyParam2(BeaurifyJniSdk.MG_BEAUTIFY_LIP, Util.CURRENT_MG_BEAUTIFY_LIP, Util.DEAFULT_LIP_COLOR[index * 3], Util.DEAFULT_LIP_COLOR[index * 3 + 1], Util.DEAFULT_LIP_COLOR[index * 3 + 2],
                        null,null,null,0);
                if (Util.CURRENT_MG_BEAUTIFY_LIP_COLOR_R != Util.DEAFULT_LIP_COLOR[index * 3] ||
                        Util.CURRENT_MG_BEAUTIFY_LIP_COLOR_G != Util.DEAFULT_LIP_COLOR[index * 3 + 1] ||
                        Util.CURRENT_MG_BEAUTIFY_LIP_COLOR_B != Util.DEAFULT_LIP_COLOR[index * 3 + 2]) {
                    Util.CURRENT_MG_BEAUTIFY_LIP_COLOR_R = Util.DEAFULT_LIP_COLOR[index * 3];
                    Util.CURRENT_MG_BEAUTIFY_LIP_COLOR_G = Util.DEAFULT_LIP_COLOR[index * 3 + 1];
                    Util.CURRENT_MG_BEAUTIFY_LIP_COLOR_B = Util.DEAFULT_LIP_COLOR[index * 3 + 2];
                    if (null != callback) {
                        callback.onFragmantChanged(0, 0);
                    }
                }
            }
        });

    }

}
